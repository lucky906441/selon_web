import * as React from "react";
import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  deleteDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
} from "firebase/firestore";
import { getFirebase, isFirebaseConfigured } from "./firebase";
import {
  defaultCategories,
  defaultCoupons,
  defaultFaqs,
  defaultGallery,
  defaultPackages,
  defaultServices,
  defaultSettings,
  defaultSocials,
  defaultStylists,
  defaultTestimonials,
} from "./seed-data";
import type {
  Booking,
  Category,
  Coupon,
  Faq,
  GalleryItem,
  Package,
  Service,
  SiteSettings,
  SocialLink,
  Stylist,
  Testimonial,
} from "./types";

type Store = {
  ready: boolean;
  live: boolean;
  settings: SiteSettings;
  socials: SocialLink[];
  categories: Category[];
  services: Service[];
  packages: Package[];
  stylists: Stylist[];
  gallery: GalleryItem[];
  testimonials: Testimonial[];
  faqs: Faq[];
  coupons: Coupon[];
};

const initial: Store = {
  ready: false,
  live: isFirebaseConfigured,
  settings: defaultSettings,
  socials: defaultSocials,
  categories: defaultCategories,
  services: defaultServices,
  packages: defaultPackages,
  stylists: defaultStylists,
  gallery: defaultGallery,
  testimonials: defaultTestimonials,
  faqs: defaultFaqs,
  coupons: defaultCoupons,
};

const StoreContext = React.createContext<Store>({ ...initial, ready: true });

const COLLECTIONS: Array<[keyof Store, string]> = [
  ["socials", "socials"],
  ["categories", "categories"],
  ["services", "services"],
  ["packages", "packages"],
  ["stylists", "stylists"],
  ["gallery", "gallery"],
  ["testimonials", "testimonials"],
  ["faqs", "faqs"],
  ["coupons", "coupons"],
];

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = React.useState<Store>({ ...initial, ready: !isFirebaseConfigured });

  React.useEffect(() => {
    if (!isFirebaseConfigured) return;
    const { db } = getFirebase();
    if (!db) return;
    const unsubs: Array<() => void> = [];

    unsubs.push(
      onSnapshot(doc(db, "settings", "site"), (snap) => {
        if (snap.exists()) {
          setState((p) => ({
            ...p,
            ready: true,
            settings: { ...defaultSettings, ...(snap.data() as Partial<SiteSettings>) },
          }));
        } else {
          setState((p) => ({ ...p, ready: true }));
        }
      }),
    );

    for (const [key, name] of COLLECTIONS) {
      unsubs.push(
        onSnapshot(collection(db, name), (snap) => {
          if (snap.empty) return;
          const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() })) as never[];
          setState((p) => ({ ...p, ready: true, [key]: rows }) as Store);
        }),
      );
    }
    return () => unsubs.forEach((u) => u());
  }, []);

  const value = React.useMemo(() => {
    const sortByOrder = <T extends { order?: number }>(a: T[]) =>
      [...a].sort((x, y) => (x.order ?? 0) - (y.order ?? 0));
    return {
      ...state,
      socials: sortByOrder(state.socials),
      categories: sortByOrder(state.categories),
      services: sortByOrder(state.services),
      packages: sortByOrder(state.packages),
      gallery: sortByOrder(state.gallery),
      testimonials: sortByOrder(state.testimonials),
      faqs: sortByOrder(state.faqs),
    };
  }, [state]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  return React.useContext(StoreContext);
}

/* ---------------- write helpers (admin panel) ---------------- */

export async function saveSettings(patch: Partial<SiteSettings>) {
  const { db } = getFirebase();
  if (!db) throw new Error("Firebase not configured");
  await setDoc(doc(db, "settings", "site"), patch, { merge: true });
}

export async function saveDoc(col: string, id: string, data: Record<string, unknown>) {
  const { db } = getFirebase();
  if (!db) throw new Error("Firebase not configured");
  await setDoc(doc(db, col, id), data, { merge: true });
}

export async function removeDoc(col: string, id: string) {
  const { db } = getFirebase();
  if (!db) throw new Error("Firebase not configured");
  await deleteDoc(doc(db, col, id));
}

export async function createBooking(b: Booking) {
  const { db } = getFirebase();
  if (!db) return { ok: false as const, offline: true as const };
  const ref = await addDoc(collection(db, "bookings"), b as unknown as Record<string, unknown>);
  return { ok: true as const, id: ref.id };
}

export async function fetchBookings(): Promise<Booking[]> {
  const { db } = getFirebase();
  if (!db) return [];
  const snap = await getDocs(collection(db, "bookings"));
  return snap.docs.map((d) => ({ id: d.id, ...(d.data() as Booking) }));
}

export function subscribeBookings(cb: (rows: Booking[]) => void) {
  const { db } = getFirebase();
  if (!db) return () => {};
  return onSnapshot(collection(db, "bookings"), (snap) => {
    cb(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Booking) })));
  });
}

export async function updateBooking(id: string, patch: Partial<Booking>) {
  const { db } = getFirebase();
  if (!db) throw new Error("Firebase not configured");
  await updateDoc(doc(db, "bookings", id), patch as Record<string, unknown>);
}

export async function fetchBookedSlots(date: string): Promise<string[]> {
  const { db } = getFirebase();
  if (!db) return [];
  const snap = await getDocs(
    query(collection(db, "bookings"), where("date", "==", date)),
  );
  return snap.docs
    .map((d) => d.data() as Booking)
    .filter((b) => b.status !== "cancelled")
    .map((b) => b.timeSlot);
}

/** Seed all default content into Firestore (admin "Load default data"). */
export async function seedFirestore() {
  const { db } = getFirebase();
  if (!db) throw new Error("Firebase not configured");
  await setDoc(doc(db, "settings", "site"), defaultSettings, { merge: true });
  const sets: Array<[string, Array<{ id: string }>]> = [
    ["socials", defaultSocials],
    ["categories", defaultCategories],
    ["services", defaultServices],
    ["packages", defaultPackages],
    ["stylists", defaultStylists],
    ["gallery", defaultGallery],
    ["testimonials", defaultTestimonials],
    ["faqs", defaultFaqs],
    ["coupons", defaultCoupons],
  ];
  for (const [name, rows] of sets) {
    for (const row of rows) {
      const { id, ...rest } = row;
      await setDoc(doc(db, name, id), rest, { merge: true });
    }
  }
}
