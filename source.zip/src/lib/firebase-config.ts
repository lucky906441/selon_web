/**
 * =============================================================
 *  FIREBASE CONFIG — FILL THESE VALUES YOURSELF
 * =============================================================
 *  Firebase Console -> Project Settings -> Your apps -> Web app
 *  Copy the config values into the strings below.
 *
 *  Jotokkhon eta faka thakbe, website 100% kaj korbe default
 *  (seed) data diye. Fill korle sob kichu Firestore theke live
 *  load hobe ar Admin Panel theke control kora jabe.
 * =============================================================
 */
export const firebaseConfig = {
  apiKey: "AIzaSyDwgy3cvRZbClO5J5d8d4mxhDT_VLbNhKs",
  authDomain: "mehak-s-makeover-unisex-salon.firebaseapp.com",
  databaseURL:
    "https://mehak-s-makeover-unisex-salon-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "mehak-s-makeover-unisex-salon",
  storageBucket: "mehak-s-makeover-unisex-salon.firebasestorage.app",
  messagingSenderId: "409856495296",
  appId: "1:409856495296:web:d3854f0c25557545fb6725",
  measurementId: "G-M0B8WRWP11",
};

export const isFirebaseConfigured = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId,
);
