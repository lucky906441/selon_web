import * as React from "react";
import {
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  sendPasswordResetEmail,
  browserLocalPersistence,
  setPersistence,
  type User,
} from "firebase/auth";
import { getFirebase, isFirebaseConfigured } from "./firebase";

export function useAdminAuth() {
  const [user, setUser] = React.useState<User | null>(null);
  const [loading, setLoading] = React.useState(isFirebaseConfigured);

  React.useEffect(() => {
    if (!isFirebaseConfigured) return;
    const { auth } = getFirebase();
    if (!auth) return;
    return onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
    });
  }, []);

  return { user, loading, configured: isFirebaseConfigured };
}

export async function adminLogin(email: string, password: string) {
  const { auth } = getFirebase();
  if (!auth) throw new Error("Firebase is not configured yet.");
  await setPersistence(auth, browserLocalPersistence);
  await signInWithEmailAndPassword(auth, email, password);
}

export async function adminLogout() {
  const { auth } = getFirebase();
  if (auth) await signOut(auth);
}

export async function adminReset(email: string) {
  const { auth } = getFirebase();
  if (!auth) throw new Error("Firebase is not configured yet.");
  await sendPasswordResetEmail(auth, email);
}
