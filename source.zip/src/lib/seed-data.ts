import type {
  Category,
  Coupon,
  Faq,
  GalleryItem,
  Package,
  Service,
  SiteSettings,
  SocialLink,
  Stylist,
  Testimonial,
} from "./types";

const P = (n: string) =>
  `https://wsrv.nl/?url=https://i.ibb.co/${n}w=1080&q=95&output=webp&we`;

export const PHOTOS = [
  P("xqXPHrqH/mehaks-makeover-photo-1.jpg"),
  P("j9VWbyhw/mehaks-makeover-photo-2.jpg"),
  P("gbCY1NCW/mehaks-makeover-photo-3.jpg"),
  P("ynMJZphw/mehaks-makeover-photo-4.jpg"),
  P("CXMD2qq/mehaks-makeover-photo-5.jpg"),
  P("Z1Vv42y7/mehaks-makeover-photo-6.jpg"),
  P("mFd1Kx6R/mehaks-makeover-photo-7.jpg"),
  P("JRtX3RjD/mehaks-makeover-photo-8.jpg"),
  P("SGdGFfM/mehaks-makeover-photo-10.jpg"),
  P("VcxwCdTr/mehaks-makeover-photo-11.webp"),
  P("SXZj1X8d/mehaks-makeover-photo-12.webp"),
  P("FkGdpRVP/mehaks-makeover-photo-13.webp"),
  P("wNpgnchz/mehaks-makeover-photo-14.webp"),
  P("99tZKW9M/mehaks-makeover-photo-15.jpg"),
  P("YB7BYnmL/mehaks-makeover-photo-16.jpg"),
  P("mC830rg8/mehaks-makeover-photo-17.jpg"),
  P("cSpdvRCG/mehaks-makeover-photo-18.jpg"),
  P("hJTxC8Xx/mehaks-makeover-photo-19.jpg"),
  P("HDcskCNR/mehaks-makeover-photo-20.jpg"),
  P("2773YxyY/mehaks-makeover-photo-21.jpg"),
];

export const LOGO_MAIN = P("Tx15Hqrz/mehaks-makeover-main-logo.png");
export const LOGO_SECOND = P("Fq6RTBLs/mehaks-makeover-second-logo.png");

export const defaultSettings: SiteSettings = {
  name: "Mehak's Makeover",
  fullName: "Mehak's Makeover Unisex Salon",
  tagline: "Where Beauty Meets Artistry",
  phone: "+919438662612",
  whatsapp: "919438662612",
  email: "hello@mehaksmakeover.in",
  address:
    "4th floor, Janata City Centre, Telephone Bhawan Rd, near KFC, Godavarish Nagar, Brahmapur, Odisha 760001",
  logoMain: LOGO_MAIN,
  logoSecondary: LOGO_SECOND,
  // Exact pin: 19.3059 N, 84.7992 E — Janata City Centre, Telephone Bhawan Rd (near KFC)
  mapEmbedUrl:
    "https://www.google.com/maps?q=19.3059,84.7992(Mehak%27s+Makeover+Unisex+Salon)&ll=19.3059,84.7992&z=18&hl=en&output=embed",
  mapDirectionsUrl:
    "https://www.google.com/maps/dir/?api=1&destination=19.3059%2C84.7992&travelmode=driving",

  announcementText:
    "✦ Monsoon Glow Offer — Flat 20% off on all Bridal & Pre-Bridal packages ✦ Home service available across Brahmapur ✦",
  announcementActive: true,
  homeServiceEnabled: true,
  slotIntervalMin: 30,
  slotCapacity: 2,
  minLeadMinutes: 30,
  maxAdvanceDays: 60,
  openingHours: {
    Monday: { open: "10:00", close: "20:30", closed: false },
    Tuesday: { open: "10:00", close: "20:30", closed: false },
    Wednesday: { open: "10:00", close: "20:30", closed: false },
    Thursday: { open: "10:00", close: "20:30", closed: false },
    Friday: { open: "10:00", close: "21:00", closed: false },
    Saturday: { open: "09:30", close: "21:00", closed: false },
    Sunday: { open: "10:00", close: "20:00", closed: false },
  },
  stats: { clients: 12500, years: 9, services: 60, stylists: 8 },
};

export const defaultSocials: SocialLink[] = [
  {
    id: "instagram",
    label: "Instagram",
    url: "https://www.instagram.com/mehaks_makeover/",
    icon: "instagram",
    visible: true,
    order: 1,
  },
  {
    id: "facebook",
    label: "Facebook",
    url: "https://www.facebook.com/mehaksmakeover/",
    icon: "facebook",
    visible: true,
    order: 2,
  },
  {
    id: "googleMaps",
    label: "Google Maps",
    url: defaultSettings.mapDirectionsUrl,
    icon: "map",
    visible: true,
    order: 3,
  },
  {
    id: "whatsapp",
    label: "WhatsApp",
    url: "https://wa.me/919438662612",
    icon: "whatsapp",
    visible: true,
    order: 4,
  },
  {
    id: "youtube",
    label: "YouTube",
    url: "https://www.youtube.com/",
    icon: "youtube",
    visible: false,
    order: 5,
  },
];

export const defaultCategories: Category[] = [
  { id: "hair", name: "Hair", icon: "scissors", order: 1, visible: true },
  { id: "skin", name: "Skin & Facial", icon: "sparkles", order: 2, visible: true },
  { id: "makeup", name: "Makeup", icon: "brush", order: 3, visible: true },
  { id: "bridal", name: "Bridal", icon: "crown", order: 4, visible: true },
  { id: "nails", name: "Nails", icon: "hand", order: 5, visible: true },
  { id: "spa", name: "Spa & Massage", icon: "flower", order: 6, visible: true },
  { id: "threading", name: "Threading & Waxing", icon: "wand", order: 7, visible: true },
  { id: "men", name: "Men's Grooming", icon: "user", order: 8, visible: true },
];

let sOrder = 0;
const s = (
  id: string,
  name: string,
  categoryId: string,
  price: number,
  durationMin: number,
  description: string,
  forGender: Service["forGender"] = "all",
  popular = false,
): Service => ({
  id,
  name,
  categoryId,
  price,
  durationMin,
  description,
  forGender,
  popular,
  visible: true,
  order: ++sOrder,
});

export const defaultServices: Service[] = [
  s("hair-cut-f", "Ladies Haircut & Styling", "hair", 399, 45, "Consultation, wash, precision cut and blow-dry finish.", "female", true),
  s("hair-cut-m", "Men's Haircut", "hair", 149, 30, "Classic or trend cut with wash and styling.", "male"),
  s("hair-wash", "Hair Wash & Blow Dry", "hair", 249, 30, "Deep cleanse with salon-grade shampoo and gloss blow-dry."),
  s("hair-spa", "Hair Spa Treatment", "hair", 899, 60, "Nourishing spa ritual for shine, strength and scalp health.", "all", true),
  s("keratin", "Keratin Treatment", "hair", 3999, 150, "Frizz-free, glass-smooth hair that lasts for months.", "all", true),
  s("smoothening", "Hair Smoothening", "hair", 3499, 150, "Silky manageable hair with long-lasting smooth finish."),
  s("rebonding", "Hair Rebonding", "hair", 4499, 180, "Poker-straight, salon-perfect results."),
  s("hair-colour", "Global Hair Colour", "hair", 1799, 90, "Ammonia-free global colour in your chosen shade."),
  s("highlights", "Highlights / Balayage", "hair", 2999, 150, "Hand-painted dimension and depth."),
  s("root-touch", "Root Touch-up", "hair", 699, 45, "Neat, seamless regrowth coverage."),
  s("head-massage", "Head Massage", "hair", 399, 30, "Relaxing oil massage to relieve stress."),

  s("cleanup", "Clean-up", "skin", 499, 30, "Quick deep-cleanse for instant freshness."),
  s("fruit-facial", "Fruit Facial", "skin", 799, 45, "Vitamin-rich glow facial for all skin types."),
  s("gold-facial", "Gold Facial", "skin", 1499, 60, "24k radiance ritual for special occasions.", "all", true),
  s("diamond-facial", "Diamond Facial", "skin", 1899, 60, "Luminous, camera-ready skin."),
  s("hydra-facial", "Hydra Facial", "skin", 2499, 75, "Medical-grade hydration and deep cleanse.", "all", true),
  s("detan", "De-Tan Treatment", "skin", 599, 30, "Removes tan, evens out skin tone."),
  s("bleach", "Face Bleach", "skin", 399, 25, "Gentle brightening for a fresh look."),

  s("party-makeup", "Party Makeup", "makeup", 1499, 60, "Glam evening look built to last all night."),
  s("engagement-makeup", "Engagement Makeup", "makeup", 3499, 90, "Elegant, photo-perfect engagement glam."),
  s("hd-makeup", "HD Makeup", "makeup", 4499, 90, "High-definition finish for flawless photos.", "all", true),
  s("airbrush", "Airbrush Makeup", "makeup", 6999, 120, "Feather-light airbrush base with luxury finish."),
  s("saree-draping", "Saree Draping", "makeup", 499, 30, "Professional draping in any style."),

  s("bridal-basic", "Bridal Makeup — Classic", "bridal", 9999, 180, "Full bridal look with drape and hair styling."),
  s("bridal-premium", "Bridal Makeup — Premium HD", "bridal", 15999, 210, "HD bridal glam with premium products.", "all", true),
  s("bridal-luxury", "Bridal Makeup — Luxury Airbrush", "bridal", 24999, 240, "Signature airbrush bridal package."),
  s("pre-bridal", "Pre-Bridal Package", "bridal", 11999, 300, "Multi-session skin, hair and body prep."),
  s("groom-package", "Groom Package", "bridal", 4999, 150, "Complete grooming for the big day.", "male"),

  s("manicure", "Manicure", "nails", 499, 40, "Shape, cuticle care, massage and polish."),
  s("pedicure", "Pedicure", "nails", 699, 50, "Detox soak, scrub and deep foot care.", "all", true),
  s("nail-art", "Nail Art", "nails", 599, 45, "Custom hand-painted nail designs."),
  s("gel-extension", "Gel Nail Extensions", "nails", 1999, 90, "Durable, natural-looking extensions."),

  s("body-massage", "Full Body Massage", "spa", 1499, 60, "Aroma relaxation massage for total unwind.", "all", true),
  s("body-polish", "Body Polishing", "spa", 2499, 75, "Full-body exfoliation for luminous skin."),
  s("body-spa", "Luxury Body Spa", "spa", 3499, 90, "Scrub, wrap and massage indulgence."),

  s("eyebrow", "Eyebrow Threading", "threading", 60, 10, "Precise shaping for defined brows.", "female"),
  s("upper-lip", "Upper Lip", "threading", 40, 5, "Quick and gentle threading.", "female"),
  s("full-face-thread", "Full Face Threading", "threading", 299, 25, "Complete face threading."),
  s("full-arms-wax", "Full Arms Waxing", "threading", 399, 30, "Smooth, long-lasting results."),
  s("full-legs-wax", "Full Legs Waxing", "threading", 599, 40, "Silky-smooth legs."),
  s("rica-wax", "Rica Wax — Full Body", "threading", 2499, 90, "Premium low-pain Italian wax.", "all", true),

  s("beard-styling", "Beard Styling", "men", 149, 25, "Sharp beard shaping and line-up.", "male", true),
  s("shave", "Luxury Shave", "men", 199, 30, "Hot towel classic shave.", "male"),
  s("men-colour", "Men's Hair Colour", "men", 599, 45, "Natural-look colour and grey coverage.", "male"),
  s("men-facial", "Men's Facial", "men", 699, 45, "Deep cleanse tailored for men's skin.", "male"),
  s("men-detan", "Men's D-Tan", "men", 399, 30, "Instant tan removal.", "male"),
];

export const defaultPackages: Package[] = [
  {
    id: "pkg-bridal",
    name: "Signature Bridal",
    price: 24999,
    badge: "Most Popular",
    includes: [
      "Luxury airbrush bridal makeup",
      "Bridal hair styling & saree draping",
      "Pre-bridal 3-session glow plan",
      "Full body Rica waxing",
      "Complimentary trial session",
    ],
    image: PHOTOS[2],
    visible: true,
    order: 1,
  },
  {
    id: "pkg-party",
    name: "Party Glam",
    price: 2999,
    includes: [
      "HD party makeup",
      "Hair styling of choice",
      "Eyebrow threading",
      "Express clean-up",
    ],
    image: PHOTOS[5],
    visible: true,
    order: 2,
  },
  {
    id: "pkg-groom",
    name: "Groom Grooming",
    price: 4999,
    includes: [
      "Premium haircut & beard sculpt",
      "D-tan + men's facial",
      "Manicure & pedicure",
      "Head massage",
    ],
    image: PHOTOS[8],
    visible: true,
    order: 3,
  },
];

export const defaultStylists: Stylist[] = [
  { id: "any", name: "Any Available Artist", specialty: "First free expert", photo: LOGO_SECOND, rating: 4.9, visible: true },
  { id: "mehak", name: "Mehak", specialty: "Bridal & HD Makeup", photo: PHOTOS[10], rating: 5, visible: true },
  { id: "riya", name: "Riya", specialty: "Hair Colour & Keratin", photo: PHOTOS[11], rating: 4.8, visible: true },
  { id: "sneha", name: "Sneha", specialty: "Skin & Hydra Facial", photo: PHOTOS[12], rating: 4.9, visible: true },
  { id: "arjun", name: "Arjun", specialty: "Men's Grooming", photo: PHOTOS[13], rating: 4.8, visible: true },
];

export const defaultGallery: GalleryItem[] = PHOTOS.map((url, i) => ({
  id: `g${i + 1}`,
  url,
  caption: `Mehak's Makeover — look ${i + 1}`,
  category: ["Bridal", "Hair", "Makeup", "Salon"][i % 4],
  order: i + 1,
  visible: true,
}));

export const defaultTestimonials: Testimonial[] = [
  { id: "t1", name: "Ananya Patnaik", rating: 5, text: "My bridal makeup was beyond perfect. It stayed flawless for 14 hours straight. Best salon in Brahmapur, hands down.", date: "2026-05-12", visible: true, order: 1 },
  { id: "t2", name: "Sradha Mishra", rating: 5, text: "The hydra facial gave me glass skin. Very clean, hygienic and the staff are so warm.", date: "2026-04-28", visible: true, order: 2 },
  { id: "t3", name: "Rakesh Sahu", rating: 5, text: "Best men's grooming in the city. Beard styling is next level and booking online is super easy.", date: "2026-06-02", visible: true, order: 3 },
  { id: "t4", name: "Priyanka Das", rating: 5, text: "Got keratin done here — silky hair for months. Worth every rupee.", date: "2026-03-19", visible: true, order: 4 },
  { id: "t5", name: "Jyoti Behera", rating: 4, text: "Loved the pedicure and nail art. Ambience feels like a 5-star studio.", date: "2026-06-21", visible: true, order: 5 },
];

export const defaultFaqs: Faq[] = [
  { id: "f1", question: "Do I need an appointment?", answer: "Walk-ins are welcome, but online booking guarantees your slot and preferred artist. Booking takes under a minute.", order: 1, visible: true },
  { id: "f2", question: "Do you offer home service?", answer: "Yes. Home service is available across Brahmapur for makeup, bridal and selected services. Choose 'Home Service' during booking.", order: 2, visible: true },
  { id: "f3", question: "Which products do you use?", answer: "We use professional brands like MAC, Huda Beauty, Kryolan, L'Oreal Professionnel, Schwarzkopf and Rica.", order: 3, visible: true },
  { id: "f4", question: "How do I pay?", answer: "Pay at the salon by cash, UPI or card. Online advance payment is coming soon.", order: 4, visible: true },
  { id: "f5", question: "Can I reschedule or cancel?", answer: "Yes — call or WhatsApp us with your Booking ID at least 2 hours before your slot.", order: 5, visible: true },
  { id: "f6", question: "Is the salon unisex?", answer: "Yes, Mehak's Makeover is a unisex salon with dedicated areas and trained artists for men and women.", order: 6, visible: true },
];

export const defaultCoupons: Coupon[] = [
  { id: "c1", code: "GLOW20", type: "percent", value: 20, minAmount: 1000, active: true },
  { id: "c2", code: "FIRST100", type: "flat", value: 100, minAmount: 500, active: true },
];

export const WHY_US = [
  { title: "Premium Products", desc: "Only professional, dermatologist-safe international brands." },
  { title: "Trained Artists", desc: "Certified stylists with years of bridal and editorial experience." },
  { title: "Hygiene First", desc: "Sanitised tools, disposable kits and spotless studio standards." },
  { title: "Affordable Luxury", desc: "5-star experience at honest, transparent prices." },
  { title: "On-Time Service", desc: "Slot-based booking means no waiting, ever." },
  { title: "Home Service", desc: "We bring the studio to your doorstep across Brahmapur." },
];
