import type { SiteSettings } from "./types";

export function pad(n: number) {
  return n.toString().padStart(2, "0");
}

export function toISODate(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function dayName(d: Date) {
  return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][d.getDay()];
}

export function prettyDate(iso: string) {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" });
}

export function to12h(t: string) {
  const [h, m] = t.split(":").map(Number);
  const ampm = h >= 12 ? "PM" : "AM";
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${pad(m)} ${ampm}`;
}

/** Build selectable dates respecting maxAdvanceDays and closed days. */
export function buildDates(settings: SiteSettings) {
  const out: { iso: string; date: Date; closed: boolean }[] = [];
  const today = new Date();
  for (let i = 0; i < Math.min(settings.maxAdvanceDays, 60); i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    const hours = settings.openingHours[dayName(d)];
    out.push({ iso: toISODate(d), date: d, closed: Boolean(hours?.closed) });
  }
  return out;
}

/** Generate time slots for a given date from opening hours + interval. */
export function buildSlots(settings: SiteSettings, iso: string) {
  const d = new Date(`${iso}T00:00:00`);
  const hours = settings.openingHours[dayName(d)];
  if (!hours || hours.closed) return [];
  const [oh, om] = hours.open.split(":").map(Number);
  const [ch, cm] = hours.close.split(":").map(Number);
  const start = oh * 60 + om;
  const end = ch * 60 + cm;
  const now = new Date();
  const isToday = toISODate(now) === iso;
  const cutoff = now.getHours() * 60 + now.getMinutes() + settings.minLeadMinutes;

  const slots: string[] = [];
  for (let t = start; t + settings.slotIntervalMin <= end; t += settings.slotIntervalMin) {
    if (isToday && t < cutoff) continue;
    slots.push(`${pad(Math.floor(t / 60))}:${pad(t % 60)}`);
  }
  return slots;
}

export function makeBookingId() {
  const d = new Date();
  const rnd = Math.floor(1000 + Math.random() * 9000);
  return `MM-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${rnd}`;
}

export function inr(n: number) {
  return `₹${n.toLocaleString("en-IN")}`;
}

export function durationLabel(min: number) {
  if (min < 60) return `${min} min`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}
