export type SocialLink = {
  id: string;
  label: string;
  url: string;
  icon: string;
  visible: boolean;
  order: number;
};

export type Service = {
  id: string;
  name: string;
  categoryId: string;
  price: number;
  offerPrice?: number;
  durationMin: number;
  description: string;
  forGender: "all" | "female" | "male";
  popular?: boolean;
  visible: boolean;
  order: number;
};

export type Category = {
  id: string;
  name: string;
  icon: string;
  order: number;
  visible: boolean;
};

export type Package = {
  id: string;
  name: string;
  price: number;
  badge?: string;
  includes: string[];
  image: string;
  visible: boolean;
  order: number;
};

export type Stylist = {
  id: string;
  name: string;
  specialty: string;
  photo: string;
  rating: number;
  visible: boolean;
};

export type GalleryItem = {
  id: string;
  url: string;
  caption: string;
  category: string;
  order: number;
  visible: boolean;
};

export type Testimonial = {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
  visible: boolean;
  order: number;
};

export type Faq = {
  id: string;
  question: string;
  answer: string;
  order: number;
  visible: boolean;
};

export type DayHours = { open: string; close: string; closed: boolean };

export type SiteSettings = {
  name: string;
  fullName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  logoMain: string;
  logoSecondary: string;
  mapEmbedUrl: string;
  mapDirectionsUrl: string;
  announcementText: string;
  announcementActive: boolean;
  homeServiceEnabled: boolean;
  slotIntervalMin: number;
  slotCapacity: number;
  minLeadMinutes: number;
  maxAdvanceDays: number;
  openingHours: Record<string, DayHours>;
  stats: { clients: number; years: number; services: number; stylists: number };
};

export type Booking = {
  id?: string;
  bookingId: string;
  name: string;
  phone: string;
  email: string;
  gender: string;
  serviceIds: string[];
  serviceNames: string[];
  stylistId: string;
  stylistName: string;
  date: string;
  timeSlot: string;
  locationType: "salon" | "home";
  address: string;
  persons: number;
  notes: string;
  amount: number;
  discount: number;
  finalAmount: number;
  couponCode: string;
  paymentMode: string;
  status: "pending" | "confirmed" | "completed" | "cancelled" | "no-show";
  createdAt: string;
};

export type Coupon = {
  id: string;
  code: string;
  type: "percent" | "flat";
  value: number;
  minAmount: number;
  active: boolean;
};
