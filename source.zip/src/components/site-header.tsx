import * as React from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X, Phone, CalendarCheck } from "lucide-react";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/gallery", label: "Gallery" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const { settings } = useStore();
  const [open, setOpen] = React.useState(false);
  const [solid, setSolid] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  React.useEffect(() => setOpen(false), [pathname]);

  React.useEffect(() => {
    const onScroll = () => {
      setSolid(window.scrollY > 24);
      const h = document.body.scrollHeight - window.innerHeight;
      setProgress(h > 0 ? (window.scrollY / h) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  React.useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          solid ? "glass shadow-lux" : "bg-transparent",
        )}
      >
        <div className="mx-auto grid h-20 max-w-[1320px] grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 sm:h-24 sm:px-6 lg:flex lg:justify-between">
          <Link to="/" className="flex min-w-0 items-center gap-3">
            <img
              src={settings.logoMain}
              alt={`${settings.fullName} logo`}
              className="h-14 w-auto shrink-0 rounded-2xl sm:h-[4.5rem]"
              width={72}
              height={72}
            />
            <span className="min-w-0 font-display text-lg leading-tight sm:text-2xl">
              <span className="block truncate">{settings.name}</span>
              <span className="mt-1 block text-[9px] font-sans uppercase tracking-[0.26em] text-gold sm:text-[10px]">
                Unisex Salon
              </span>
            </span>
          </Link>


          <nav className="hidden items-center gap-1 lg:flex">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="rounded-full px-4 py-2 text-sm text-muted-foreground transition-colors hover:text-gold"
                activeProps={{ className: "text-gold" }}
                activeOptions={{ exact: n.to === "/" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${settings.phone}`}
              className="hidden size-10 place-items-center rounded-full border border-border text-gold transition-colors hover:bg-surface-2 sm:grid"
              aria-label="Call the salon"
            >
              <Phone size={17} />
            </a>
            <Link
              to="/booking"
              className="hidden items-center gap-2 rounded-full bg-gold-gradient px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-lux transition-transform hover:scale-[1.03] sm:inline-flex"
            >
              <CalendarCheck size={16} /> Book Now
            </Link>
            <button
              onClick={() => setOpen((v) => !v)}
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              className="grid size-10 place-items-center rounded-full border border-border text-gold lg:hidden"
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
        <div
          className="h-px origin-left bg-gold-gradient transition-transform duration-150"
          style={{ transform: `scaleX(${progress / 100})` }}
        />
      </header>

      {/* Mobile fullscreen menu */}
      <div
        className={cn(
          "fixed inset-0 z-40 flex flex-col justify-center bg-background/97 px-8 backdrop-blur-xl transition-all duration-400 lg:hidden",
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0",
        )}
      >
        <nav className="flex flex-col gap-1">
          {NAV.map((n, i) => (
            <Link
              key={n.to}
              to={n.to}
              style={{ transitionDelay: `${i * 55}ms` }}
              className={cn(
                "border-b border-border/60 py-4 font-display text-3xl transition-all duration-500",
                open ? "translate-x-0 opacity-100" : "translate-x-6 opacity-0",
              )}
            >
              {n.label}
            </Link>
          ))}
          <Link
            to="/booking"
            className="mt-8 inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-6 py-4 font-semibold text-primary-foreground"
          >
            <CalendarCheck size={18} /> Book Appointment
          </Link>
          <a
            href={`tel:${settings.phone}`}
            className="mt-3 inline-flex items-center justify-center gap-2 rounded-full border border-border px-6 py-4 text-gold"
          >
            <Phone size={18} /> {settings.phone}
          </a>
        </nav>
      </div>
    </>
  );
}
