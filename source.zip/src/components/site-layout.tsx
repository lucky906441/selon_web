import * as React from "react";
import { SiteHeader } from "./site-header";
import { SiteFooter } from "./site-footer";
import { FloatingBooking } from "./floating-booking";
import { useStore } from "@/lib/store";
import { isFirebaseConfigured } from "@/lib/firebase";
import { AlertTriangle } from "lucide-react";

export function SiteLayout({ children }: { children: React.ReactNode }) {
  const { settings } = useStore();

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      {/* Ambient aura background */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -left-40 top-[-10%] size-[46rem] rounded-full bg-gold/10 blur-[130px] animate-aura" />
        <div className="absolute -right-32 top-1/3 size-[38rem] rounded-full bg-rose/10 blur-[130px] animate-aura [animation-delay:-5s]" />
        <div className="absolute bottom-0 left-1/3 size-[34rem] rounded-full bg-gold/8 blur-[140px] animate-aura [animation-delay:-9s]" />
      </div>

      <SiteHeader />

      {settings.announcementActive && settings.announcementText && (
        <div className="fixed inset-x-0 top-20 z-30 overflow-hidden bg-gold-gradient py-2 shadow-lux sm:top-24">
          <div className="flex w-max animate-marquee items-center gap-8 whitespace-nowrap pl-8 text-[10px] font-semibold uppercase tracking-[0.22em] text-primary-foreground sm:text-[11px]">
            {Array.from({ length: 4 }).map((_, i) => (
              <span key={i} className="flex items-center gap-8">
                <span>{settings.announcementText}</span>
                <span className="opacity-70">✦</span>
              </span>
            ))}
          </div>
        </div>
      )}


      <main className="pt-20 sm:pt-24">{children}</main>

      <SiteFooter />
      <FloatingBooking />

      {!isFirebaseConfigured && <FirebaseNotice />}
    </div>
  );
}

function FirebaseNotice() {
  const [hidden, setHidden] = React.useState(false);
  if (hidden) return null;
  return (
    <button
      onClick={() => setHidden(true)}
      className="fixed bottom-3 left-3 z-40 flex max-w-[16rem] items-start gap-2 rounded-xl glass px-3 py-2 text-left text-[11px] leading-snug text-muted-foreground"
    >
      <AlertTriangle size={14} className="mt-0.5 shrink-0 text-gold" />
      <span>
        Demo mode — add your Firebase keys in <code className="text-gold">src/lib/firebase-config.ts</code> to
        enable live bookings & admin panel. Tap to hide.
      </span>
    </button>
  );
}
