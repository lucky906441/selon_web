import * as React from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import type { GalleryItem } from "@/lib/types";

export function Lightbox({
  items,
  index,
  onClose,
}: {
  items: GalleryItem[];
  index: number | null;
  onClose: () => void;
}) {
  const [i, setI] = React.useState(index ?? 0);
  React.useEffect(() => setI(index ?? 0), [index]);

  React.useEffect(() => {
    if (index === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setI((v) => (v + 1) % items.length);
      if (e.key === "ArrowLeft") setI((v) => (v - 1 + items.length) % items.length);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [index, items.length, onClose]);

  if (index === null) return null;
  const item = items[i];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Gallery image"
      className="fixed inset-0 z-[60] flex items-center justify-center bg-background/95 p-4 backdrop-blur-xl"
      onClick={onClose}
    >
      <button
        aria-label="Close"
        onClick={onClose}
        className="absolute right-4 top-4 grid size-11 place-items-center rounded-full glass text-gold"
      >
        <X size={20} />
      </button>
      <button
        aria-label="Previous"
        onClick={(e) => {
          e.stopPropagation();
          setI((v) => (v - 1 + items.length) % items.length);
        }}
        className="absolute left-3 grid size-11 place-items-center rounded-full glass text-gold sm:left-6"
      >
        <ChevronLeft size={22} />
      </button>
      <button
        aria-label="Next"
        onClick={(e) => {
          e.stopPropagation();
          setI((v) => (v + 1) % items.length);
        }}
        className="absolute right-3 grid size-11 place-items-center rounded-full glass text-gold sm:right-6"
      >
        <ChevronRight size={22} />
      </button>

      <figure onClick={(e) => e.stopPropagation()} className="max-h-[86vh] max-w-4xl">
        <img
          src={item.url}
          alt={item.caption}
          className="max-h-[76vh] w-auto rounded-2xl object-contain shadow-lux"
        />
        <figcaption className="mt-3 text-center text-sm text-muted-foreground">
          {item.caption} · {i + 1}/{items.length}
        </figcaption>
      </figure>
    </div>
  );
}
