import * as React from "react";
import { Link } from "@tanstack/react-router";
import { CalendarCheck, Phone, MessageCircle, Navigation, Plus, X } from "lucide-react";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

/** Premium floating booking button + speed-dial (call / WhatsApp / directions). */
export function FloatingBooking() {
  const { settings } = useStore();
  const [visible, setVisible] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const lastY = React.useRef(0);

  React.useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setVisible(y > 260 && (y < lastY.current || y < 400));
      lastY.current = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const mini = [
    {
      label: "Call now",
      href: `tel:${settings.phone}`,
      Icon: Phone,
    },
    {
      label: "WhatsApp",
      href: `https://wa.me/${settings.whatsapp}?text=${encodeURIComponent("Hi! I'd like to book an appointment at Mehak's Makeover.")}`,
      Icon: MessageCircle,
    },
    {
      label: "Directions",
      href: settings.mapDirectionsUrl,
      Icon: Navigation,
    },
  ];

  return (
    <div
      className={cn(
        "fixed bottom-[max(1rem,env(safe-area-inset-bottom))] right-4 z-40 flex flex-col items-end gap-3 transition-all duration-500 sm:bottom-6 sm:right-6",
        visible ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0",
      )}
    >
      <div className="flex flex-col items-end gap-2.5">
        {mini.map((m, i) => (
          <a
            key={m.label}
            href={m.href}
            target={m.href.startsWith("http") ? "_blank" : undefined}
            rel="noreferrer noopener"
            aria-label={m.label}
            style={{ transitionDelay: `${i * 50}ms` }}
            className={cn(
              "grid size-11 place-items-center rounded-full glass text-gold shadow-lux transition-all duration-300",
              open ? "translate-y-0 scale-100 opacity-100" : "pointer-events-none translate-y-3 scale-75 opacity-0",
            )}
          >
            <m.Icon size={18} />
          </a>
        ))}
      </div>

      <div className="flex items-center gap-2.5">
        <button
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close quick actions" : "Open quick actions"}
          className="grid size-11 place-items-center rounded-full glass text-gold shadow-lux transition-transform hover:scale-105"
        >
          {open ? <X size={18} /> : <Plus size={18} />}
        </button>

        <Link
          to="/booking"
          className="group inline-flex items-center gap-2 rounded-full bg-gold-gradient px-5 py-3.5 text-sm font-bold text-primary-foreground shadow-lux animate-pulse-ring transition-transform hover:scale-[1.04]"
        >
          <CalendarCheck size={18} className="transition-transform group-hover:rotate-6" />
          Book Now
        </Link>
      </div>
    </div>
  );
}
