import {
  Facebook,
  Instagram,
  MapPin,
  MessageCircle,
  Youtube,
  Link2,
  Twitter,
  Globe,
} from "lucide-react";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const ICONS: Record<string, React.ElementType> = {
  instagram: Instagram,
  facebook: Facebook,
  map: MapPin,
  googlemaps: MapPin,
  whatsapp: MessageCircle,
  youtube: Youtube,
  twitter: Twitter,
  x: Twitter,
  website: Globe,
};

export function SocialIcons({ className, size = 18 }: { className?: string; size?: number }) {
  const { socials } = useStore();
  const visible = socials.filter((s) => s.visible && s.url);
  if (!visible.length) return null;

  return (
    <div className={cn("flex flex-wrap items-center gap-2.5", className)}>
      {visible.map((s) => {
        const Icon = ICONS[s.icon?.toLowerCase()] ?? Link2;
        return (
          <a
            key={s.id}
            href={s.url}
            target="_blank"
            rel="noreferrer noopener"
            aria-label={s.label}
            title={s.label}
            className="group grid size-10 place-items-center rounded-full border border-border bg-surface-2/70 text-muted-foreground transition-all hover:-translate-y-0.5 hover:border-gold hover:text-gold hover:glow-gold"
          >
            <Icon size={size} />
          </a>
        );
      })}
    </div>
  );
}
