import * as React from "react";
import {
  Phone,
  MessageCircle,
  Check,
  X,
  Clock,
  MapPin,
  IndianRupee,
  Search,
  Download,
} from "lucide-react";
import { AdminInput, AdminSelect, Card } from "./ui";
import { subscribeBookings, fetchBookings, updateBooking } from "@/lib/store";
import type { Booking } from "@/lib/types";
import { inr, prettyDate, to12h } from "@/lib/booking-utils";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const STATUSES: Booking["status"][] = [
  "pending",
  "confirmed",
  "completed",
  "cancelled",
  "no-show",
];

const statusCls: Record<string, string> = {
  pending: "border-gold/50 text-gold",
  confirmed: "border-emerald-500/50 text-emerald-400",
  completed: "border-sky-500/50 text-sky-400",
  cancelled: "border-destructive/50 text-destructive",
  "no-show": "border-border text-muted-foreground",
};

export function useBookings() {
  const [rows, setRows] = React.useState<Booking[]>([]);
  React.useEffect(() => {
    let alive = true;
    fetchBookings().then((r) => alive && setRows(r));
    const unsub = subscribeBookings((r) => alive && setRows(r));
    return () => {
      alive = false;
      unsub?.();
    };
  }, []);
  return rows;
}

export function BookingsTab({ rows }: { rows: Booking[] }) {
  const [q, setQ] = React.useState("");
  const [status, setStatus] = React.useState("all");

  const list = rows.filter(
    (b) =>
      (status === "all" || b.status === status) &&
      `${b.name} ${b.phone} ${b.bookingId} ${b.serviceNames?.join(" ")}`
        .toLowerCase()
        .includes(q.toLowerCase()),
  );

  const setStatusOf = async (b: Booking, s: Booking["status"]) => {
    try {
      await updateBooking(b.id ?? b.bookingId, { status: s });
      toast.success(`Marked ${s}`);
    } catch {
      toast.error("Connect Firebase to update bookings");
    }
  };

  const exportCsv = () => {
    const head = "Booking ID,Name,Phone,Date,Slot,Services,Artist,Amount,Status";
    const body = list
      .map((b) =>
        [
          b.bookingId,
          b.name,
          b.phone,
          b.date,
          b.timeSlot,
          `"${(b.serviceNames ?? []).join(" | ")}"`,
          b.stylistName,
          b.finalAmount,
          b.status,
        ].join(","),
      )
      .join("\n");
    const url = URL.createObjectURL(new Blob([`${head}\n${body}`], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `bookings-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-xl">Bookings</h2>
        <button
          onClick={exportCsv}
          className="inline-flex items-center gap-1.5 rounded-full border border-border px-3.5 py-2 text-xs text-gold"
        >
          <Download size={14} /> CSV
        </button>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div className="relative">
          <Search size={15} className="absolute left-3.5 top-3 text-muted-foreground" />
          <AdminInput
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name, phone, ID…"
            className="pl-10"
          />
        </div>
        <AdminSelect value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="all">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </AdminSelect>
      </div>

      {list.length === 0 && (
        <Card className="text-center text-sm text-muted-foreground">
          No bookings yet. New online bookings appear here in real time.
        </Card>
      )}

      {list.map((b) => (
        <Card key={b.bookingId} className="space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="truncate font-medium">{b.name}</p>
              <p className="text-[11px] text-muted-foreground">{b.bookingId}</p>
            </div>
            <span
              className={cn(
                "shrink-0 rounded-full border px-2.5 py-1 text-[10px] uppercase tracking-wider",
                statusCls[b.status],
              )}
            >
              {b.status}
            </span>
          </div>

          <ul className="space-y-1.5 text-xs text-muted-foreground">
            <li className="flex items-center gap-2">
              <Clock size={13} className="text-gold" />
              {prettyDate(b.date)} · {to12h(b.timeSlot)}
            </li>
            <li className="flex items-start gap-2">
              <MapPin size={13} className="mt-0.5 text-gold" />
              {b.locationType === "home" ? b.address || "Home service" : "In salon"} ·{" "}
              {b.stylistName}
            </li>
            <li className="flex items-center gap-2">
              <IndianRupee size={13} className="text-gold" />
              {inr(b.finalAmount)}
              {b.discount > 0 && ` (saved ${inr(b.discount)})`} · {b.paymentMode}
            </li>
            <li className="line-clamp-2">{(b.serviceNames ?? []).join(", ")}</li>
            {b.notes && <li className="italic">“{b.notes}”</li>}
          </ul>

          <div className="flex flex-wrap gap-2">
            <a
              href={`tel:${b.phone}`}
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs text-gold"
            >
              <Phone size={13} /> Call
            </a>
            <a
              href={`https://wa.me/91${b.phone}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs text-gold"
            >
              <MessageCircle size={13} /> WhatsApp
            </a>
            {b.status !== "confirmed" && (
              <button
                onClick={() => setStatusOf(b, "confirmed")}
                className="inline-flex items-center gap-1.5 rounded-full bg-gold-gradient px-3 py-2 text-xs font-bold text-primary-foreground"
              >
                <Check size={13} /> Confirm
              </button>
            )}
            {b.status !== "completed" && (
              <button
                onClick={() => setStatusOf(b, "completed")}
                className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs text-muted-foreground"
              >
                Done
              </button>
            )}
            {b.status !== "cancelled" && (
              <button
                onClick={() => setStatusOf(b, "cancelled")}
                className="inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs text-destructive"
              >
                <X size={13} /> Cancel
              </button>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}
