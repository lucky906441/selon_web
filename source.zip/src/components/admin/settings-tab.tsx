import * as React from "react";
import { Save } from "lucide-react";
import { AdminInput, AdminTextarea, Card, Field, GoldButton, Toggle } from "./ui";
import { saveSettings, useStore } from "@/lib/store";
import type { SiteSettings } from "@/lib/types";
import { toast } from "sonner";

export function SettingsTab() {
  const { settings } = useStore();
  const [s, setS] = React.useState<SiteSettings>(settings);
  React.useEffect(() => setS(settings), [settings]);

  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) =>
    setS((p) => ({ ...p, [k]: v }));

  const save = async () => {
    try {
      await saveSettings(s);
      toast.success("Settings saved");
    } catch {
      toast.error("Connect Firebase to save settings");
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-xl">Site settings</h2>
        <GoldButton onClick={save}>
          <Save size={15} /> Save
        </GoldButton>
      </div>

      <Card className="grid gap-3 sm:grid-cols-2">
        <Field label="Salon name">
          <AdminInput value={s.name} onChange={(e) => set("name", e.target.value)} />
        </Field>
        <Field label="Full name">
          <AdminInput value={s.fullName} onChange={(e) => set("fullName", e.target.value)} />
        </Field>
        <Field label="Tagline">
          <AdminInput value={s.tagline} onChange={(e) => set("tagline", e.target.value)} />
        </Field>
        <Field label="Phone">
          <AdminInput value={s.phone} onChange={(e) => set("phone", e.target.value)} />
        </Field>
        <Field label="WhatsApp (with 91)">
          <AdminInput value={s.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} />
        </Field>
        <Field label="Email">
          <AdminInput value={s.email} onChange={(e) => set("email", e.target.value)} />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Address">
            <AdminTextarea value={s.address} onChange={(e) => set("address", e.target.value)} />
          </Field>
        </div>
      </Card>

      <Card className="grid gap-3 sm:grid-cols-2">
        <Field label="Main logo URL">
          <AdminInput value={s.logoMain} onChange={(e) => set("logoMain", e.target.value)} />
        </Field>
        <Field label="Secondary logo URL">
          <AdminInput
            value={s.logoSecondary}
            onChange={(e) => set("logoSecondary", e.target.value)}
          />
        </Field>
        <div className="sm:col-span-2">
          <Field label="Google Map embed URL">
            <AdminInput value={s.mapEmbedUrl} onChange={(e) => set("mapEmbedUrl", e.target.value)} />
          </Field>
        </div>
        <div className="sm:col-span-2">
          <Field label="Google Map directions URL">
            <AdminInput
              value={s.mapDirectionsUrl}
              onChange={(e) => set("mapDirectionsUrl", e.target.value)}
            />
          </Field>
        </div>
      </Card>

      <Card className="space-y-3">
        <Field label="Announcement text">
          <AdminInput
            value={s.announcementText}
            onChange={(e) => set("announcementText", e.target.value)}
          />
        </Field>
        <Toggle
          label="Show announcement bar"
          checked={s.announcementActive}
          onChange={(v) => set("announcementActive", v)}
        />
        <Toggle
          label="Enable home service bookings"
          checked={s.homeServiceEnabled}
          onChange={(v) => set("homeServiceEnabled", v)}
        />
      </Card>

      <Card className="grid gap-3 sm:grid-cols-2">
        <Field label="Slot interval (minutes)">
          <AdminInput
            type="number"
            value={s.slotIntervalMin}
            onChange={(e) => set("slotIntervalMin", Number(e.target.value))}
          />
        </Field>
        <Field label="Bookings per slot">
          <AdminInput
            type="number"
            value={s.slotCapacity}
            onChange={(e) => set("slotCapacity", Number(e.target.value))}
          />
        </Field>
        <Field label="Minimum lead time (minutes)">
          <AdminInput
            type="number"
            value={s.minLeadMinutes}
            onChange={(e) => set("minLeadMinutes", Number(e.target.value))}
          />
        </Field>
        <Field label="Book up to (days ahead)">
          <AdminInput
            type="number"
            value={s.maxAdvanceDays}
            onChange={(e) => set("maxAdvanceDays", Number(e.target.value))}
          />
        </Field>
      </Card>

      <Card className="space-y-2">
        <p className="text-[11px] uppercase tracking-wider text-muted-foreground">
          Opening hours
        </p>
        {Object.entries(s.openingHours).map(([day, h]) => (
          <div key={day} className="flex items-center gap-2">
            <span className="w-24 shrink-0 text-xs text-muted-foreground">{day}</span>
            <AdminInput
              value={h.open}
              onChange={(e) =>
                set("openingHours", {
                  ...s.openingHours,
                  [day]: { ...h, open: e.target.value },
                })
              }
            />
            <AdminInput
              value={h.close}
              onChange={(e) =>
                set("openingHours", {
                  ...s.openingHours,
                  [day]: { ...h, close: e.target.value },
                })
              }
            />
            <button
              type="button"
              onClick={() =>
                set("openingHours", {
                  ...s.openingHours,
                  [day]: { ...h, closed: !h.closed },
                })
              }
              className={`shrink-0 rounded-full border px-3 py-2 text-[11px] ${
                h.closed ? "border-destructive/60 text-destructive" : "border-border text-gold"
              }`}
            >
              {h.closed ? "Closed" : "Open"}
            </button>
          </div>
        ))}
      </Card>

      <Card className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {(["clients", "years", "services", "stylists"] as const).map((k) => (
          <Field key={k} label={k}>
            <AdminInput
              type="number"
              value={s.stats[k]}
              onChange={(e) => set("stats", { ...s.stats, [k]: Number(e.target.value) })}
            />
          </Field>
        ))}
      </Card>

      <GoldButton onClick={save} className="w-full">
        <Save size={15} /> Save all settings
      </GoldButton>
    </div>
  );
}
