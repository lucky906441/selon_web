import * as React from "react";
import { Plus, Trash2, Save, Search } from "lucide-react";
import { AdminInput, AdminTextarea, Card, GhostButton, GoldButton, Field } from "./ui";
import { saveDoc, removeDoc } from "@/lib/store";
import { toast } from "sonner";

export type FieldDef = {
  key: string;
  label: string;
  type?: "text" | "number" | "textarea" | "boolean" | "image";
};

type Row = Record<string, unknown> & { id: string };

export function CollectionEditor({
  title,
  collection,
  rows,
  fields,
  makeNew,
  titleKey = "name",
}: {
  title: string;
  collection: string;
  rows: Row[];
  fields: FieldDef[];
  makeNew: () => Row;
  titleKey?: string;
}) {
  const [draft, setDraft] = React.useState<Row | null>(null);
  const [q, setQ] = React.useState("");

  const filtered = rows.filter((r) =>
    String(r[titleKey] ?? r.id)
      .toLowerCase()
      .includes(q.toLowerCase()),
  );

  const save = async () => {
    if (!draft) return;
    try {
      await saveDoc(collection, draft.id, draft);
      toast.success("Saved");
      setDraft(null);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Connect Firebase to save changes");
    }
  };

  const del = async (id: string) => {
    try {
      await removeDoc(collection, id);
      toast.success("Deleted");
    } catch {
      toast.error("Connect Firebase to delete");
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h2 className="font-display text-xl">{title}</h2>
        <GoldButton onClick={() => setDraft(makeNew())}>
          <Plus size={15} /> New
        </GoldButton>
      </div>

      <div className="relative">
        <Search size={15} className="absolute left-3.5 top-3 text-muted-foreground" />
        <AdminInput
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search…"
          className="pl-10"
        />
      </div>

      {draft && (
        <Card className="border-gold/40">
          <h3 className="mb-3 text-sm font-semibold text-gold">Editing</h3>
          <div className="grid gap-3 sm:grid-cols-2">
            {fields.map((f) => (
              <div key={f.key} className={f.type === "textarea" ? "sm:col-span-2" : ""}>
                <Field label={f.label}>
                  {f.type === "textarea" ? (
                    <AdminTextarea
                      value={String(draft[f.key] ?? "")}
                      onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value })}
                    />
                  ) : f.type === "boolean" ? (
                    <AdminInput
                      type="checkbox"
                      className="size-6 accent-[var(--gold)]"
                      checked={Boolean(draft[f.key])}
                      onChange={(e) => setDraft({ ...draft, [f.key]: e.target.checked })}
                    />
                  ) : (
                    <AdminInput
                      type={f.type === "number" ? "number" : "text"}
                      value={String(draft[f.key] ?? "")}
                      onChange={(e) =>
                        setDraft({
                          ...draft,
                          [f.key]:
                            f.type === "number" ? Number(e.target.value) : e.target.value,
                        })
                      }
                    />
                  )}
                </Field>
                {f.type === "image" && String(draft[f.key] ?? "") && (
                  <img
                    src={String(draft[f.key])}
                    alt=""
                    className="mt-2 h-24 w-24 rounded-xl object-cover object-top"
                  />
                )}
              </div>
            ))}
          </div>
          <div className="mt-4 flex gap-2">
            <GoldButton onClick={save}>
              <Save size={15} /> Save
            </GoldButton>
            <GhostButton onClick={() => setDraft(null)}>Cancel</GhostButton>
          </div>
        </Card>
      )}

      <div className="space-y-2">
        {filtered.map((r) => (
          <Card key={r.id} className="flex items-center justify-between gap-3">
            <button
              onClick={() => setDraft({ ...r })}
              className="min-w-0 flex-1 text-left"
            >
              <p className="truncate text-sm font-medium">{String(r[titleKey] ?? r.id)}</p>
              <p className="truncate text-[11px] text-muted-foreground">{r.id}</p>
            </button>
            <button
              onClick={() => del(r.id)}
              aria-label="Delete"
              className="grid size-9 shrink-0 place-items-center rounded-xl border border-border text-destructive hover:border-destructive"
            >
              <Trash2 size={15} />
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
}
