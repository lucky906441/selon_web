import { Link } from "@tanstack/react-router";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useStore } from "@/lib/store";
import { SocialIcons } from "./social-icons";

export function SiteFooter() {
  const { settings } = useStore();
  const year = new Date().getFullYear();

  return (
    <footer className="relative mt-24 border-t border-border bg-surface/60">
      <div className="pointer-events-none absolute inset-x-0 -top-px h-px bg-gold-gradient opacity-60" />
      <div className="mx-auto grid max-w-[1320px] gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <img
            src={settings.logoMain}
            alt={`${settings.fullName} logo`}
            className="h-14 w-auto"
            loading="lazy"
          />
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
            {settings.fullName} — {settings.tagline}. Brahmapur's premium unisex beauty studio for
            hair, skin, makeup and bridal artistry.
          </p>
          <SocialIcons className="mt-5" />
        </div>

        <div>
          <h3 className="font-display text-lg">Explore</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-muted-foreground">
            {[
              { to: "/", label: "Home" },
              { to: "/services", label: "Services & Prices" },
              { to: "/gallery", label: "Gallery" },
              { to: "/booking", label: "Book Appointment" },
              { to: "/about", label: "About Us" },
              { to: "/contact", label: "Contact" },
            ].map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="transition-colors hover:text-gold">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-lg">Opening Hours</h3>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {Object.entries(settings.openingHours).map(([day, h]) => (
              <li key={day} className="flex justify-between gap-3">
                <span>{day.slice(0, 3)}</span>
                <span className={h.closed ? "text-destructive" : "text-foreground/85"}>
                  {h.closed ? "Closed" : `${h.open} – ${h.close}`}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-display text-lg">Visit Us</h3>
          <ul className="mt-4 space-y-3.5 text-sm text-muted-foreground">
            <li className="flex gap-3">
              <MapPin size={17} className="mt-0.5 shrink-0 text-gold" />
              <a href={settings.mapDirectionsUrl} target="_blank" rel="noreferrer" className="hover:text-gold">
                {settings.address}
              </a>
            </li>
            <li className="flex gap-3">
              <Phone size={17} className="shrink-0 text-gold" />
              <a href={`tel:${settings.phone}`} className="hover:text-gold">
                {settings.phone}
              </a>
            </li>
            <li className="flex gap-3">
              <Mail size={17} className="shrink-0 text-gold" />
              <a href={`mailto:${settings.email}`} className="hover:text-gold">
                {settings.email}
              </a>
            </li>
            <li className="flex gap-3">
              <Clock size={17} className="shrink-0 text-gold" />
              <span>Open 7 days a week</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/70">
        <div className="mx-auto flex max-w-[1320px] flex-col items-center justify-between gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:px-6">
          <p>
            © {year} {settings.fullName}. All rights reserved.
          </p>
          <Link to="/admin" className="transition-colors hover:text-gold">
            Admin Panel
          </Link>
        </div>
      </div>
    </footer>
  );
}
