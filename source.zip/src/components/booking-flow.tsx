import * as React from "react";
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Clock,
  IndianRupee,
  MessageCircle,
  Sparkles,
  CalendarDays,
  MapPin,
  Home,
  Loader2,
} from "lucide-react";
import { useStore, createBooking, fetchBookedSlots } from "@/lib/store";
import {
  buildDates,
  buildSlots,
  durationLabel,
  inr,
  makeBookingId,
  prettyDate,
  to12h,
} from "@/lib/booking-utils";
import type { Booking } from "@/lib/types";
import { cn } from "@/lib/utils";

const STEPS = ["Services", "Date & Time", "Details", "Confirm"];
const PAYMENT_MODE = "Cash on Delivery (pay after service)";

export function BookingFlow() {
  const { settings, categories, services, stylists } = useStore();
  const [step, setStep] = React.useState(0);
  const [cat, setCat] = React.useState(categories[0]?.id ?? "hair");
  const [picked, setPicked] = React.useState<string[]>([]);
  const [date, setDate] = React.useState("");
  const [slot, setSlot] = React.useState("");
  const [taken, setTaken] = React.useState<string[]>([]);
  const [loadingSlots, setLoadingSlots] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);
  const [done, setDone] = React.useState<Booking | null>(null);
  const [error, setError] = React.useState("");
  const stylist = "any";
  const discount = 0;

  const [form, setForm] = React.useState({
    name: "",
    phone: "",
    email: "",
    gender: "female",
    locationType: "salon" as "salon" | "home",
    address: "",
    persons: 1,
    notes: "",
    consent: false,
  });


  const dates = React.useMemo(() => buildDates(settings), [settings]);
  const slots = React.useMemo(
    () => (date ? buildSlots(settings, date) : []),
    [settings, date],
  );
  const chosen = services.filter((s) => picked.includes(s.id));
  const amount = chosen.reduce((t, s) => t + (s.offerPrice ?? s.price), 0);
  const totalMin = chosen.reduce((t, s) => t + s.durationMin, 0);
  const finalAmount = Math.max(0, amount - discount);

  React.useEffect(() => {
    if (!date) return;
    let alive = true;
    setLoadingSlots(true);
    fetchBookedSlots(date)
      .then((r) => alive && setTaken(r))
      .finally(() => alive && setLoadingSlots(false));
    return () => {
      alive = false;
    };
  }, [date]);

  const toggle = (id: string) =>
    setPicked((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const canNext = [
    picked.length > 0,
    Boolean(date && slot),
    form.name.trim().length > 1 &&
      /^[6-9]\d{9}$/.test(form.phone.trim()) &&
      form.consent &&
      (form.locationType === "salon" || form.address.trim().length > 5),
    true,
  ][step];


  const submit = async () => {
    setSubmitting(true);
    setError("");
    const stylistObj = stylists.find((s) => s.id === stylist);
    const booking: Booking = {
      bookingId: makeBookingId(),
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      gender: form.gender,
      serviceIds: picked,
      serviceNames: chosen.map((s) => s.name),
      stylistId: stylist,
      stylistName: stylistObj?.name ?? "Any Available Artist",
      date,
      timeSlot: slot,
      locationType: form.locationType,
      address: form.locationType === "home" ? form.address.trim() : settings.address,
      persons: Number(form.persons) || 1,
      notes: form.notes.trim(),
      amount,
      discount,
      finalAmount,
      couponCode: "",
      paymentMode: PAYMENT_MODE,

      status: "pending",
      createdAt: new Date().toISOString(),
    };
    try {
      await createBooking(booking);
      setDone(booking);
    } catch {
      setError("Could not save the booking. Please call us or send it on WhatsApp.");
      setDone(booking);
    } finally {
      setSubmitting(false);
    }
  };

  if (done) return <BookingSuccess booking={done} error={error} />;

  return (
    <div className="mx-auto w-full max-w-4xl">
      {/* Stepper */}
      <ol className="no-scrollbar mb-8 flex gap-2 overflow-x-auto">
        {STEPS.map((s, i) => (
          <li key={s} className="flex min-w-fit flex-1 items-center gap-2">
            <span
              className={cn(
                "grid size-8 shrink-0 place-items-center rounded-full border text-xs font-bold transition-colors",
                i < step && "border-gold bg-gold-gradient text-primary-foreground",
                i === step && "border-gold text-gold glow-gold",
                i > step && "border-border text-muted-foreground",
              )}
            >
              {i < step ? <Check size={14} /> : i + 1}
            </span>
            <span
              className={cn(
                "whitespace-nowrap text-xs sm:text-sm",
                i === step ? "text-gold" : "text-muted-foreground",
              )}
            >
              {s}
            </span>
            {i < STEPS.length - 1 && <span className="hidden h-px flex-1 bg-border sm:block" />}
          </li>
        ))}
      </ol>

      <div className="rounded-3xl glass p-4 shadow-lux sm:p-7">
        {/* STEP 1 — services */}
        {step === 0 && (
          <div>
            <h3 className="font-display text-2xl">Choose your services</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Select one or more — you can mix categories in a single visit.
            </p>
            <div className="no-scrollbar mt-5 flex gap-2 overflow-x-auto pb-1">
              {categories
                .filter((c) => c.visible)
                .map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setCat(c.id)}
                    className={cn(
                      "whitespace-nowrap rounded-full border px-4 py-2 text-sm transition-all",
                      cat === c.id
                        ? "border-gold bg-gold-gradient text-primary-foreground"
                        : "border-border text-muted-foreground hover:text-gold",
                    )}
                  >
                    {c.name}
                  </button>
                ))}
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-2">
              {services
                .filter((s) => s.visible && s.categoryId === cat)
                .map((s) => {
                  const on = picked.includes(s.id);
                  return (
                    <button
                      key={s.id}
                      onClick={() => toggle(s.id)}
                      className={cn(
                        "rounded-2xl border p-4 text-left transition-all",
                        on
                          ? "border-gold bg-surface-2 glow-gold"
                          : "border-border bg-surface/60 hover:border-gold/50",
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <span className="font-medium">{s.name}</span>
                        <span
                          className={cn(
                            "grid size-5 shrink-0 place-items-center rounded-md border",
                            on ? "border-gold bg-gold-gradient" : "border-border",
                          )}
                        >
                          {on && <Check size={12} className="text-primary-foreground" />}
                        </span>
                      </div>
                      <p className="mt-1.5 line-clamp-2 text-xs text-muted-foreground">
                        {s.description}
                      </p>
                      <div className="mt-3 flex items-center gap-3 text-xs">
                        <span className="font-semibold text-gold">
                          {inr(s.offerPrice ?? s.price)}
                        </span>
                        <span className="flex items-center gap-1 text-muted-foreground">
                          <Clock size={12} /> {durationLabel(s.durationMin)}
                        </span>
                      </div>
                    </button>
                  );
                })}
            </div>
          </div>
        )}

        {/* STEP 2 — date & time */}
        {step === 1 && (

          <div>
            <h3 className="font-display text-2xl">Select date & time</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Booked and past slots are hidden automatically.
            </p>
            <div className="no-scrollbar mt-5 flex gap-2 overflow-x-auto pb-1">
              {dates.slice(0, 30).map((d) => (
                <button
                  key={d.iso}
                  disabled={d.closed}
                  onClick={() => {
                    setDate(d.iso);
                    setSlot("");
                  }}
                  className={cn(
                    "min-w-[74px] rounded-2xl border px-3 py-3 text-center transition-all",
                    d.closed && "cursor-not-allowed opacity-35",
                    date === d.iso
                      ? "border-gold bg-gold-gradient text-primary-foreground"
                      : "border-border bg-surface/60 hover:border-gold/50",
                  )}
                >
                  <span className="block text-[10px] uppercase tracking-widest">
                    {d.date.toLocaleDateString("en-IN", { weekday: "short" })}
                  </span>
                  <span className="block font-display text-xl leading-tight">
                    {d.date.getDate()}
                  </span>
                  <span className="block text-[10px]">
                    {d.date.toLocaleDateString("en-IN", { month: "short" })}
                  </span>
                </button>
              ))}
            </div>

            {date && (
              <div className="mt-6">
                <p className="mb-3 flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock size={14} className="text-gold" /> Available slots for {prettyDate(date)}
                  {loadingSlots && <Loader2 size={14} className="animate-spin" />}
                </p>
                {slots.length === 0 ? (
                  <p className="rounded-2xl border border-border bg-surface/60 p-4 text-sm text-muted-foreground">
                    No slots left for this day. Please choose another date.
                  </p>
                ) : (
                  <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
                    {slots.map((t) => {
                      const used =
                        taken.filter((x) => x === t).length >= settings.slotCapacity;
                      return (
                        <button
                          key={t}
                          disabled={used}
                          onClick={() => setSlot(t)}
                          className={cn(
                            "rounded-xl border px-2 py-2.5 text-xs transition-all",
                            used && "cursor-not-allowed line-through opacity-35",
                            slot === t
                              ? "border-gold bg-gold-gradient font-semibold text-primary-foreground"
                              : "border-border bg-surface/60 hover:border-gold/50",
                          )}
                        >
                          {to12h(t)}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* STEP 3 — details */}
        {step === 2 && (

          <div>
            <h3 className="font-display text-2xl">Your details</h3>
            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <Field label="Full name *">
                <input
                  className={inputCls}
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Your name"
                />
              </Field>
              <Field label="Mobile number *">
                <input
                  className={inputCls}
                  inputMode="numeric"
                  maxLength={10}
                  value={form.phone}
                  onChange={(e) =>
                    setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })
                  }
                  placeholder="10-digit mobile"
                />
              </Field>
              <Field label="Email (optional)">
                <input
                  className={inputCls}
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@email.com"
                />
              </Field>
              <Field label="Gender">
                <select
                  className={inputCls}
                  value={form.gender}
                  onChange={(e) => setForm({ ...form, gender: e.target.value })}
                >
                  <option value="female">Female</option>
                  <option value="male">Male</option>
                  <option value="other">Other</option>
                </select>
              </Field>

              <Field label="Service location">
                <div className="flex gap-2">
                  <button
                    onClick={() => setForm({ ...form, locationType: "salon" })}
                    className={cn(
                      "flex flex-1 items-center justify-center gap-2 rounded-xl border py-2.5 text-sm",
                      form.locationType === "salon"
                        ? "border-gold bg-surface-2 text-gold"
                        : "border-border text-muted-foreground",
                    )}
                  >
                    <MapPin size={15} /> In-Salon
                  </button>
                  {settings.homeServiceEnabled && (
                    <button
                      onClick={() => setForm({ ...form, locationType: "home" })}
                      className={cn(
                        "flex flex-1 items-center justify-center gap-2 rounded-xl border py-2.5 text-sm",
                        form.locationType === "home"
                          ? "border-gold bg-surface-2 text-gold"
                          : "border-border text-muted-foreground",
                      )}
                    >
                      <Home size={15} /> Home Service
                    </button>
                  )}
                </div>
              </Field>
              <Field label="Number of persons">
                <input
                  className={inputCls}
                  type="number"
                  min={1}
                  max={20}
                  value={form.persons}
                  onChange={(e) => setForm({ ...form, persons: Number(e.target.value) })}
                />
              </Field>

              {form.locationType === "home" && (
                <Field label="Full address for home service *" className="sm:col-span-2">
                  <input
                    className={inputCls}
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    placeholder="House / flat, street, landmark, pincode"
                  />
                </Field>
              )}

              <Field label="Special requests / notes" className="sm:col-span-2">
                <textarea
                  className={cn(inputCls, "min-h-24 resize-y")}
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="Allergies, occasion, preferred look, reference images…"
                />
              </Field>

              <div className="rounded-xl border border-gold/40 bg-surface-2/60 px-3.5 py-3 text-xs text-muted-foreground sm:col-span-2">
                Payment: <span className="font-semibold text-gold">{PAYMENT_MODE}</span> — no
                advance payment needed.
              </div>

            </div>

            <label className="mt-5 flex cursor-pointer items-start gap-3 text-sm text-muted-foreground">
              <input
                type="checkbox"
                checked={form.consent}
                onChange={(e) => setForm({ ...form, consent: e.target.checked })}
                className="mt-1 size-4 accent-[oklch(0.79_0.09_82)]"
              />
              I agree to the salon's booking terms and allow Mehak's Makeover to contact me about
              this appointment.
            </label>
          </div>
        )}

        {/* STEP 5 — review */}
        {step === 3 && (
          <div>
            <h3 className="font-display text-2xl">Review & confirm</h3>
            <div className="mt-5 space-y-3 rounded-2xl border border-border bg-surface/60 p-4 text-sm">
              <Row label="Name" value={form.name} />
              <Row label="Mobile" value={form.phone} />
              <Row
                label="Services"
                value={chosen.map((s) => s.name).join(", ") || "—"}
              />
              <Row label="Date & time" value={`${prettyDate(date)} • ${to12h(slot)}`} />
              <Row label="Duration" value={durationLabel(totalMin)} />
              <Row
                label="Location"
                value={form.locationType === "home" ? `Home — ${form.address}` : "In-Salon"}
              />
              <Row label="Persons" value={String(form.persons)} />
              {form.notes && <Row label="Notes" value={form.notes} />}
              <div className="my-2 h-px bg-border" />
              <div className="flex items-center justify-between pt-1">
                <span className="font-display text-lg">Total payable</span>
                <span className="font-display text-2xl text-gradient-gold">{inr(finalAmount)}</span>
              </div>
              <p className="text-xs text-muted-foreground">{PAYMENT_MODE}</p>
            </div>
          </div>
        )}


        {/* Footer bar */}
        <div className="mt-7 flex flex-col-reverse gap-3 border-t border-border pt-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-4 text-sm">
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Sparkles size={14} className="text-gold" /> {picked.length} selected
            </span>
            <span className="flex items-center gap-1 font-semibold text-gold">
              <IndianRupee size={14} />
              {finalAmount.toLocaleString("en-IN")}
            </span>
            {totalMin > 0 && (
              <span className="hidden items-center gap-1.5 text-muted-foreground sm:flex">
                <Clock size={14} /> {durationLabel(totalMin)}
              </span>
            )}
          </div>
          <div className="flex gap-2">
            {step > 0 && (
              <button
                onClick={() => setStep((s) => s - 1)}
                className="inline-flex items-center gap-1.5 rounded-full border border-border px-5 py-3 text-sm"
              >
                <ChevronLeft size={16} /> Back
              </button>
            )}
            {step < STEPS.length - 1 ? (
              <button
                disabled={!canNext}
                onClick={() => setStep((s) => s + 1)}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full bg-gold-gradient px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-40 sm:flex-none"
              >
                Continue <ChevronRight size={16} />
              </button>
            ) : (
              <button
                disabled={submitting}
                onClick={submit}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gold-gradient px-6 py-3 text-sm font-bold text-primary-foreground disabled:opacity-50 sm:flex-none"
              >
                {submitting ? <Loader2 size={16} className="animate-spin" /> : <Check size={16} />}
                Confirm Booking
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-input bg-surface-2/70 px-3.5 py-2.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground/70 focus:border-gold";

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1.5 block text-xs uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-6">
      <span className="shrink-0 text-muted-foreground">{label}</span>
      <span className="text-right">{value}</span>
    </div>
  );
}

function BookingSuccess({ booking, error }: { booking: Booking; error: string }) {
  const { settings } = useStore();
  const msg = encodeURIComponent(
    `New booking request\nID: ${booking.bookingId}\nName: ${booking.name}\nPhone: ${booking.phone}\nServices: ${booking.serviceNames.join(", ")}\nArtist: ${booking.stylistName}\nDate: ${booking.date} ${booking.timeSlot}\nLocation: ${booking.locationType}\nTotal: ₹${booking.finalAmount}`,
  );

  return (
    <div className="mx-auto max-w-xl rounded-3xl glass p-7 text-center shadow-lux">
      <div className="mx-auto grid size-16 place-items-center rounded-full bg-gold-gradient">
        <Check size={30} className="text-primary-foreground" />
      </div>
      <h3 className="mt-5 font-display text-3xl">Booking received!</h3>
      <p className="mt-2 text-sm text-muted-foreground">
        Thank you {booking.name.split(" ")[0]} — we'll confirm your slot on a quick call.
      </p>
      <p className="mt-5 rounded-2xl border border-gold/40 bg-surface-2/70 px-4 py-3 font-mono text-lg tracking-wider text-gold">
        {booking.bookingId}
      </p>
      <div className="mt-5 space-y-2 text-left text-sm">
        <Row label="Date & time" value={`${prettyDate(booking.date)} • ${to12h(booking.timeSlot)}`} />
        <Row label="Artist" value={booking.stylistName} />
        <Row label="Services" value={booking.serviceNames.join(", ")} />
        <Row label="Total" value={inr(booking.finalAmount)} />
      </div>
      {error && <p className="mt-4 text-xs text-destructive">{error}</p>}
      <div className="mt-6 flex flex-col gap-2 sm:flex-row">
        <a
          href={`https://wa.me/${settings.whatsapp}?text=${msg}`}
          target="_blank"
          rel="noreferrer"
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-gold-gradient px-5 py-3 text-sm font-bold text-primary-foreground"
        >
          <MessageCircle size={16} /> Send on WhatsApp
        </a>
        <button
          onClick={() => window.location.reload()}
          className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-border px-5 py-3 text-sm"
        >
          <CalendarDays size={16} /> New booking
        </button>
      </div>
    </div>
  );
}
