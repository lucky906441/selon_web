import { createFileRoute, Link } from "@tanstack/react-router";
import { Star, Check, ArrowRight } from "lucide-react";
import { SiteLayout } from "@/components/site-layout";
import { Reveal, SectionTitle, CountUp, Tilt } from "@/components/motion";
import { useStore } from "@/lib/store";
import { WHY_US } from "@/lib/seed-data";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Mehak's Makeover Unisex Salon, Brahmapur" },
      {
        name: "description",
        content:
          "Meet the team behind Mehak's Makeover Unisex Salon — nine years of bridal artistry, hair expertise and advanced skin care in Brahmapur, Odisha.",
      },
      { property: "og:title", content: "About Mehak's Makeover Unisex Salon" },
      {
        property: "og:description",
        content: "Our story, our artists and the standards behind Brahmapur's premium salon.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { settings, stylists, gallery } = useStore();

  return (
    <SiteLayout>
      <section className="px-4 py-16 sm:px-6">
        <SectionTitle
          eyebrow="Our story"
          title={<>Nine years of making Brahmapur glow</>}
          subtitle={`${settings.fullName} started as a small studio with one belief — that world-class beauty service should not require leaving your city. Today we're a full unisex salon serving thousands of clients a year.`}
        />

        <div className="mx-auto mt-12 grid max-w-[1320px] gap-4 sm:grid-cols-3">
          {gallery.slice(14, 17).map((g, i) => (
            <Reveal key={g.id} delay={i * 80}>
              <img
                src={g.url}
                alt={g.caption}
                loading="lazy"
                className="aspect-3/4 w-full rounded-3xl object-cover object-top shadow-lux"
              />
            </Reveal>
          ))}
        </div>

        <Reveal className="mx-auto mt-14 grid max-w-[1320px] grid-cols-2 gap-4 rounded-3xl glass p-7 lg:grid-cols-4">
          {[
            { n: settings.stats.clients, s: "+", l: "Happy Clients" },
            { n: settings.stats.years, s: "+", l: "Years" },
            { n: settings.stats.services, s: "+", l: "Services" },
            { n: settings.stats.stylists, s: "", l: "Artists" },
          ].map((x) => (
            <div key={x.l} className="text-center">
              <p className="font-display text-3xl text-gradient-gold sm:text-4xl">
                <CountUp to={x.n} suffix={x.s} />
              </p>
              <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                {x.l}
              </p>
            </div>
          ))}
        </Reveal>
      </section>

      <section className="px-4 py-12 sm:px-6">
        <SectionTitle eyebrow="The team" title="Artists behind the magic" />
        <div className="mx-auto mt-12 grid max-w-[1320px] gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stylists
            .filter((s) => s.visible && s.id !== "any")
            .map((s, i) => (
              <Reveal key={s.id} delay={i * 70}>
                <Tilt className="h-full">
                  <article className="h-full overflow-hidden rounded-3xl border border-border bg-surface/70">
                    <img
                      src={s.photo}
                      alt={s.name}
                      loading="lazy"
                      className="aspect-square w-full object-cover object-top"
                    />
                    <div className="p-5">
                      <h3 className="font-display text-xl">{s.name}</h3>
                      <p className="text-xs text-muted-foreground">{s.specialty}</p>
                      <p className="mt-2 flex items-center gap-1 text-xs text-gold">
                        <Star size={12} fill="currentColor" /> {s.rating}
                      </p>
                    </div>
                  </article>
                </Tilt>
              </Reveal>
            ))}
        </div>
      </section>

      <section className="px-4 py-16 sm:px-6">
        <SectionTitle eyebrow="Our promise" title="Standards we never compromise on" />
        <div className="mx-auto mt-12 grid max-w-[1320px] gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_US.map((w, i) => (
            <Reveal key={w.title} delay={i * 60}>
              <div className="h-full rounded-3xl border border-border bg-surface/60 p-6">
                <span className="grid size-9 place-items-center rounded-xl bg-gold-gradient">
                  <Check size={16} className="text-primary-foreground" />
                </span>
                <h3 className="mt-4 font-display text-lg">{w.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{w.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal className="mt-12 text-center">
          <Link
            to="/booking"
            className="inline-flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-4 text-sm font-bold text-primary-foreground"
          >
            Book with our team <ArrowRight size={16} />
          </Link>
        </Reveal>
      </section>
    </SiteLayout>
  );
}
