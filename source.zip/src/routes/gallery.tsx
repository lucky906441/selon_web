import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site-layout";
import { Reveal, SectionTitle } from "@/components/motion";
import { Lightbox } from "@/components/lightbox";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery — Mehak's Makeover Unisex Salon, Brahmapur" },
      {
        name: "description",
        content:
          "Browse real bridal makeup, hair colour, facial and grooming transformations from Mehak's Makeover Unisex Salon in Brahmapur.",
      },
      { property: "og:title", content: "Transformation Gallery — Mehak's Makeover" },
      {
        property: "og:description",
        content: "Real client looks from Brahmapur's premium unisex salon.",
      },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  const { gallery } = useStore();
  const [filter, setFilter] = React.useState("All");
  const [open, setOpen] = React.useState<number | null>(null);

  const cats = ["All", ...Array.from(new Set(gallery.map((g) => g.category)))];
  const items = gallery.filter((g) => g.visible && (filter === "All" || g.category === filter));

  return (
    <SiteLayout>
      <section className="px-4 py-16 sm:px-6">
        <SectionTitle
          eyebrow="Portfolio"
          title="The transformation gallery"
          subtitle="Every photo below is a real client of Mehak's Makeover."
        />

        <div className="no-scrollbar mx-auto mt-10 flex max-w-[1320px] justify-start gap-2 overflow-x-auto pb-2 sm:justify-center">
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={cn(
                "whitespace-nowrap rounded-full border px-5 py-2.5 text-sm transition-all",
                filter === c
                  ? "border-gold bg-gold-gradient font-semibold text-primary-foreground"
                  : "border-border text-muted-foreground hover:text-gold",
              )}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="mx-auto mt-8 max-w-[1320px] columns-2 gap-3 sm:columns-3 lg:columns-4">
          {items.map((g, i) => (
            <Reveal key={g.id} delay={Math.min(i, 10) * 40} className="mb-3 break-inside-avoid">
              <button
                onClick={() => setOpen(i)}
                className="group relative block w-full overflow-hidden rounded-2xl border border-border"
              >
                <img
                  src={g.url}
                  alt={g.caption}
                  loading="lazy"
                  className="w-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                />
                <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background/95 to-transparent p-3 pt-10 text-left text-[11px] text-foreground/90 opacity-0 transition-opacity group-hover:opacity-100">
                  {g.category}
                </span>
              </button>
            </Reveal>
          ))}
        </div>

        <Lightbox items={items} index={open} onClose={() => setOpen(null)} />
      </section>
    </SiteLayout>
  );
}
