import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck, Clock, MapPin } from "lucide-react";
import { SiteLayout } from "@/components/site-layout";
import { SectionTitle, Reveal } from "@/components/motion";
import { BookingFlow } from "@/components/booking-flow";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/booking")({
  head: () => ({
    meta: [
      { title: "Book an Appointment — Mehak's Makeover Unisex Salon" },
      {
        name: "description",
        content:
          "Book your salon slot online in under a minute. Choose services, artist, date and time at Mehak's Makeover Unisex Salon, Brahmapur.",
      },
      { property: "og:title", content: "Book Online — Mehak's Makeover" },
      {
        property: "og:description",
        content: "Instant online salon booking with live slot availability in Brahmapur.",
      },
    ],
  }),
  component: BookingPage,
});

function BookingPage() {
  const { settings } = useStore();
  return (
    <SiteLayout>
      <section className="px-4 py-14 sm:px-6">
        <SectionTitle
          eyebrow="Reserve your seat"
          title="Book your appointment"
          subtitle="Five quick steps. You'll get an instant booking ID and a confirmation call."
        />
        <Reveal className="mx-auto mt-8 flex max-w-4xl flex-wrap justify-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5">
            <ShieldCheck size={13} className="text-gold" /> No advance payment
          </span>
          <span className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5">
            <Clock size={13} className="text-gold" /> Live slot availability
          </span>
          <span className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1.5">
            <MapPin size={13} className="text-gold" />
            {settings.homeServiceEnabled ? "Salon or home service" : "In-salon service"}
          </span>
        </Reveal>

        <div className="mt-10">
          <BookingFlow />
        </div>
      </section>
    </SiteLayout>
  );
}
