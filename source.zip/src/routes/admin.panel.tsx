import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import {
  CalendarCheck,
  LayoutDashboard,
  Scissors,
  Users,
  Images,
  Tag,
  Star,
  HelpCircle,
  Settings2,
  Share2,
  LogOut,
  Loader2,
  Database,
  ExternalLink,
  IndianRupee,
  Layers,
} from "lucide-react";
import { useStore, seedFirestore } from "@/lib/store";
import { useAdminAuth, adminLogout } from "@/lib/admin-auth";
import { BookingsTab, useBookings } from "@/components/admin/bookings-tab";
import { SettingsTab } from "@/components/admin/settings-tab";
import { CollectionEditor } from "@/components/admin/collection-editor";
import { Card, GhostButton } from "@/components/admin/ui";
import { inr, toISODate } from "@/lib/booking-utils";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/panel")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — Mehak's Makeover" },
      { name: "description", content: "Manage bookings, services and content." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Admin Dashboard — Mehak's Makeover" },
      { property: "og:description", content: "Staff-only dashboard." },
    ],
  }),
  component: AdminPanel,
});

const TABS = [
  { id: "dash", label: "Home", icon: LayoutDashboard },
  { id: "bookings", label: "Bookings", icon: CalendarCheck },
  { id: "services", label: "Services", icon: Scissors },
  { id: "categories", label: "Categories", icon: Layers },
  { id: "packages", label: "Packages", icon: Tag },
  { id: "stylists", label: "Artists", icon: Users },
  { id: "gallery", label: "Gallery", icon: Images },
  { id: "coupons", label: "Coupons", icon: IndianRupee },
  { id: "testimonials", label: "Reviews", icon: Star },
  { id: "faqs", label: "FAQs", icon: HelpCircle },
  { id: "socials", label: "Links", icon: Share2 },
  { id: "settings", label: "Settings", icon: Settings2 },
] as const;

function AdminPanel() {
  const { user, loading, configured } = useAdminAuth();
  const navigate = useNavigate();
  const store = useStore();
  const bookings = useBookings();
  const [tab, setTab] = React.useState<(typeof TABS)[number]["id"]>("dash");

  React.useEffect(() => {
    if (configured && !loading && !user) navigate({ to: "/admin" });
  }, [configured, loading, user, navigate]);

  if (configured && loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="animate-spin text-gold" />
      </div>
    );
  }

  const today = toISODate(new Date());
  const todays = bookings.filter((b) => b.date === today);
  const pending = bookings.filter((b) => b.status === "pending");
  const revenue = bookings
    .filter((b) => b.status === "completed")
    .reduce((a, b) => a + (b.finalAmount || 0), 0);

  return (
    <div className="min-h-screen pb-28">
      <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <img src={store.settings.logoMain} alt="" className="h-9 w-auto" />
            <div>
              <p className="text-sm font-semibold">Admin Panel</p>
              <p className="text-[10px] text-muted-foreground">
                {user?.email ?? (configured ? "" : "Demo mode — Firebase not connected")}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Link
              to="/"
              className="grid size-9 place-items-center rounded-xl border border-border text-muted-foreground"
              aria-label="Open website"
            >
              <ExternalLink size={15} />
            </Link>
            <button
              onClick={async () => {
                await adminLogout();
                navigate({ to: "/admin" });
              }}
              aria-label="Log out"
              className="grid size-9 place-items-center rounded-xl border border-border text-destructive"
            >
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-5">
        {tab === "dash" && (
          <div className="space-y-3">
            <h2 className="font-display text-xl">Overview</h2>
            <div className="grid grid-cols-2 gap-3">
              {[
                { l: "Today's bookings", v: String(todays.length) },
                { l: "Pending approval", v: String(pending.length) },
                { l: "Total bookings", v: String(bookings.length) },
                { l: "Completed revenue", v: inr(revenue) },
              ].map((x) => (
                <Card key={x.l}>
                  <p className="font-display text-2xl text-gradient-gold">{x.v}</p>
                  <p className="mt-1 text-[11px] uppercase tracking-wider text-muted-foreground">
                    {x.l}
                  </p>
                </Card>
              ))}
            </div>

            <Card className="space-y-2">
              <p className="text-sm font-semibold">Quick actions</p>
              <div className="flex flex-wrap gap-2">
                <GhostButton onClick={() => setTab("bookings")}>
                  <CalendarCheck size={15} /> Bookings
                </GhostButton>
                <GhostButton onClick={() => setTab("services")}>
                  <Scissors size={15} /> Services
                </GhostButton>
                <GhostButton onClick={() => setTab("settings")}>
                  <Settings2 size={15} /> Settings
                </GhostButton>
                <GhostButton
                  onClick={async () => {
                    try {
                      await seedFirestore();
                      toast.success("Default content pushed to the database");
                    } catch {
                      toast.error("Connect Firebase first");
                    }
                  }}
                >
                  <Database size={15} /> Seed database
                </GhostButton>
              </div>
            </Card>

            <Card>
              <p className="mb-2 text-sm font-semibold">Today's schedule</p>
              {todays.length === 0 ? (
                <p className="text-xs text-muted-foreground">No appointments today.</p>
              ) : (
                <ul className="space-y-2">
                  {todays.map((b) => (
                    <li key={b.bookingId} className="flex justify-between gap-3 text-xs">
                      <span className="truncate">
                        {b.timeSlot} · {b.name}
                      </span>
                      <span className="shrink-0 text-gold">{b.status}</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
        )}

        {tab === "bookings" && <BookingsTab rows={bookings} />}
        {tab === "settings" && <SettingsTab />}

        {tab === "services" && (
          <CollectionEditor
            title="Services"
            collection="services"
            rows={store.services as never}
            makeNew={() =>
              ({
                id: `svc-${Date.now()}`,
                name: "",
                categoryId: store.categories[0]?.id ?? "hair",
                description: "",
                price: 0,
                offerPrice: 0,
                durationMin: 30,
                popular: false,
                visible: true,
                order: store.services.length + 1,
              }) as never
            }
            fields={[
              { key: "name", label: "Name" },
              { key: "categoryId", label: "Category ID" },
              { key: "price", label: "Price", type: "number" },
              { key: "offerPrice", label: "Offer price", type: "number" },
              { key: "durationMin", label: "Duration (min)", type: "number" },
              { key: "order", label: "Order", type: "number" },
              { key: "popular", label: "Popular", type: "boolean" },
              { key: "visible", label: "Visible", type: "boolean" },
              { key: "description", label: "Description", type: "textarea" },
            ]}
          />
        )}

        {tab === "categories" && (
          <CollectionEditor
            title="Categories"
            collection="categories"
            rows={store.categories as never}
            makeNew={() =>
              ({
                id: `cat-${Date.now()}`,
                name: "",
                icon: "sparkles",
                visible: true,
                order: store.categories.length + 1,
              }) as never
            }
            fields={[
              { key: "name", label: "Name" },
              { key: "icon", label: "Icon key" },
              { key: "order", label: "Order", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
            ]}
          />
        )}

        {tab === "packages" && (
          <CollectionEditor
            title="Packages"
            collection="packages"
            rows={store.packages as never}
            makeNew={() =>
              ({
                id: `pkg-${Date.now()}`,
                name: "",
                description: "",
                price: 0,
                oldPrice: 0,
                image: "",
                badge: "",
                visible: true,
                order: store.packages.length + 1,
              }) as never
            }
            fields={[
              { key: "name", label: "Name" },
              { key: "badge", label: "Badge" },
              { key: "price", label: "Price", type: "number" },
              { key: "oldPrice", label: "Old price", type: "number" },
              { key: "image", label: "Image URL", type: "image" },
              { key: "order", label: "Order", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
              { key: "description", label: "Description", type: "textarea" },
            ]}
          />
        )}

        {tab === "stylists" && (
          <CollectionEditor
            title="Artists"
            collection="stylists"
            rows={store.stylists as never}
            makeNew={() =>
              ({
                id: `sty-${Date.now()}`,
                name: "",
                specialty: "",
                photo: "",
                rating: 5,
                visible: true,
              }) as never
            }
            fields={[
              { key: "name", label: "Name" },
              { key: "specialty", label: "Specialty" },
              { key: "photo", label: "Photo URL", type: "image" },
              { key: "rating", label: "Rating", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
            ]}
          />
        )}

        {tab === "gallery" && (
          <CollectionEditor
            title="Gallery"
            collection="gallery"
            rows={store.gallery as never}
            titleKey="caption"
            makeNew={() =>
              ({
                id: `img-${Date.now()}`,
                url: "",
                caption: "",
                category: "Salon",
                visible: true,
                order: store.gallery.length + 1,
              }) as never
            }
            fields={[
              { key: "caption", label: "Caption" },
              { key: "category", label: "Category" },
              { key: "url", label: "Image URL", type: "image" },
              { key: "order", label: "Order", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
            ]}
          />
        )}

        {tab === "coupons" && (
          <CollectionEditor
            title="Coupons"
            collection="coupons"
            rows={store.coupons as never}
            titleKey="code"
            makeNew={() =>
              ({
                id: `cpn-${Date.now()}`,
                code: "",
                type: "percent",
                value: 10,
                minAmount: 0,
                active: true,
              }) as never
            }
            fields={[
              { key: "code", label: "Code" },
              { key: "type", label: "Type (percent/flat)" },
              { key: "value", label: "Value", type: "number" },
              { key: "minAmount", label: "Minimum bill", type: "number" },
              { key: "active", label: "Active", type: "boolean" },
            ]}
          />
        )}

        {tab === "testimonials" && (
          <CollectionEditor
            title="Reviews"
            collection="testimonials"
            rows={store.testimonials as never}
            makeNew={() =>
              ({
                id: `rev-${Date.now()}`,
                name: "",
                text: "",
                rating: 5,
                service: "",
                avatar: "",
                visible: true,
                order: store.testimonials.length + 1,
              }) as never
            }
            fields={[
              { key: "name", label: "Client name" },
              { key: "service", label: "Service" },
              { key: "rating", label: "Rating", type: "number" },
              { key: "avatar", label: "Avatar URL", type: "image" },
              { key: "order", label: "Order", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
              { key: "text", label: "Review", type: "textarea" },
            ]}
          />
        )}

        {tab === "faqs" && (
          <CollectionEditor
            title="FAQs"
            collection="faqs"
            rows={store.faqs as never}
            titleKey="question"
            makeNew={() =>
              ({
                id: `faq-${Date.now()}`,
                question: "",
                answer: "",
                visible: true,
                order: store.faqs.length + 1,
              }) as never
            }
            fields={[
              { key: "question", label: "Question" },
              { key: "order", label: "Order", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
              { key: "answer", label: "Answer", type: "textarea" },
            ]}
          />
        )}

        {tab === "socials" && (
          <CollectionEditor
            title="Social & map links"
            collection="socials"
            rows={store.socials as never}
            titleKey="label"
            makeNew={() =>
              ({
                id: `soc-${Date.now()}`,
                label: "",
                platform: "instagram",
                url: "",
                visible: true,
                order: store.socials.length + 1,
              }) as never
            }
            fields={[
              { key: "label", label: "Label" },
              {
                key: "platform",
                label: "Platform (instagram/facebook/google/youtube/whatsapp)",
              },
              { key: "url", label: "URL" },
              { key: "order", label: "Order", type: "number" },
              { key: "visible", label: "Visible", type: "boolean" },
            ]}
          />
        )}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/90 backdrop-blur-xl">
        <div className="no-scrollbar mx-auto flex max-w-3xl gap-1 overflow-x-auto px-2 py-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex min-w-16 shrink-0 flex-col items-center gap-1 rounded-xl px-3 py-2 text-[10px] transition-colors",
                tab === t.id ? "bg-surface-2 text-gold" : "text-muted-foreground",
              )}
            >
              <t.icon size={17} />
              {t.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
