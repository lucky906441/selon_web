import * as React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Phone, Mail, MessageCircle, Send, Clock } from "lucide-react";
import { SiteLayout } from "@/components/site-layout";
import { Reveal, SectionTitle } from "@/components/motion";
import { SocialIcons } from "@/components/social-icons";
import { useStore, saveDoc } from "@/lib/store";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Location — Mehak's Makeover Unisex Salon" },
      {
        name: "description",
        content:
          "Call, WhatsApp or visit Mehak's Makeover Unisex Salon at Janata City Centre, Telephone Bhawan Rd, Brahmapur, Odisha 760001.",
      },
      { property: "og:title", content: "Contact Mehak's Makeover Unisex Salon" },
      {
        property: "og:description",
        content: "Address, phone, opening hours and map for our Brahmapur salon.",
      },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const { settings } = useStore();
  const [form, setForm] = React.useState({ name: "", phone: "", message: "" });
  const [sending, setSending] = React.useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim() || !/^[6-9]\d{9}$/.test(form.phone)) {
      toast.error("Please enter your name and a valid 10-digit mobile number.");
      return;
    }
    setSending(true);
    try {
      await saveDoc("leads", `lead-${Date.now()}`, {
        ...form,
        source: "contact-page",
        handled: false,
        createdAt: new Date().toISOString(),
      });
      toast.success("Message sent! We'll call you shortly.");
    } catch {
      toast.success("Thanks! Please also WhatsApp us so we reply faster.");
    } finally {
      setSending(false);
      setForm({ name: "", phone: "", message: "" });
    }
  };

  const input =
    "w-full rounded-xl border border-input bg-surface-2/70 px-3.5 py-2.5 text-sm outline-none focus:border-gold";

  return (
    <SiteLayout>
      <section className="px-4 py-16 sm:px-6">
        <SectionTitle
          eyebrow="Say hello"
          title="Contact & location"
          subtitle="Questions about a service, a package or a bridal date? We're one message away."
        />

        <div className="mx-auto mt-12 grid max-w-[1320px] gap-5 lg:grid-cols-2">
          <Reveal className="rounded-3xl glass p-7 shadow-lux">
            <h3 className="font-display text-2xl">{settings.fullName}</h3>
            <ul className="mt-5 space-y-4 text-sm text-muted-foreground">
              <li className="flex gap-3">
                <MapPin size={17} className="mt-0.5 shrink-0 text-gold" />
                {settings.address}
              </li>
              <li className="flex gap-3">
                <Phone size={17} className="shrink-0 text-gold" />
                <a href={`tel:${settings.phone}`} className="hover:text-gold">
                  {settings.phone}
                </a>
              </li>
              <li className="flex gap-3">
                <Mail size={17} className="shrink-0 text-gold" />
                <a href={`mailto:${settings.email}`} className="hover:text-gold">
                  {settings.email}
                </a>
              </li>
              <li className="flex gap-3">
                <Clock size={17} className="mt-0.5 shrink-0 text-gold" />
                <span>
                  {Object.entries(settings.openingHours).map(([d, h]) => (
                    <span key={d} className="block">
                      {d}: {h.closed ? "Closed" : `${h.open} – ${h.close}`}
                    </span>
                  ))}
                </span>
              </li>
            </ul>
            <div className="mt-6 flex flex-wrap gap-2">
              <a
                href={`https://wa.me/${settings.whatsapp}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-gold-gradient px-5 py-3 text-sm font-bold text-primary-foreground"
              >
                <MessageCircle size={16} /> WhatsApp us
              </a>
              <a
                href={settings.mapDirectionsUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-3 text-sm text-gold"
              >
                <MapPin size={16} /> Directions
              </a>
            </div>
            <SocialIcons className="mt-6" />
          </Reveal>

          <Reveal delay={100} className="rounded-3xl glass p-7 shadow-lux">
            <h3 className="font-display text-2xl">Send a message</h3>
            <form onSubmit={submit} className="mt-5 space-y-4">
              <input
                className={input}
                placeholder="Your name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              <input
                className={input}
                inputMode="numeric"
                maxLength={10}
                placeholder="10-digit mobile number"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })}
              />
              <textarea
                className={`${input} min-h-32 resize-y`}
                placeholder="How can we help?"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
              />
              <button
                disabled={sending}
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient px-6 py-3.5 text-sm font-bold text-primary-foreground disabled:opacity-50"
              >
                <Send size={16} /> Send message
              </button>
            </form>
          </Reveal>
        </div>

        <Reveal className="mx-auto mt-6 max-w-[1320px] overflow-hidden rounded-3xl border border-border shadow-lux">
          <iframe
            title="Salon location map"
            src={settings.mapEmbedUrl}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="h-[24rem] w-full"
          />
        </Reveal>
      </section>
    </SiteLayout>
  );
}
