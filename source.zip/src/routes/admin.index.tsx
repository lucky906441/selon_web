import * as React from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Lock, Mail, Loader2, ArrowLeft, ShieldAlert } from "lucide-react";
import { useStore } from "@/lib/store";
import { adminLogin, adminReset, useAdminAuth } from "@/lib/admin-auth";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/")({
  head: () => ({
    meta: [
      { title: "Admin Login — Mehak's Makeover" },
      { name: "description", content: "Secure staff login for the Mehak's Makeover admin panel." },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Admin Login — Mehak's Makeover" },
      { property: "og:description", content: "Staff-only access." },
    ],
  }),
  component: AdminLogin,
});

function AdminLogin() {
  const { settings } = useStore();
  const { user, configured } = useAdminAuth();
  const navigate = useNavigate();
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    if (user) navigate({ to: "/admin/panel" });
  }, [user, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await adminLogin(email.trim(), password);
      toast.success("Welcome back!");
      navigate({ to: "/admin/panel" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Login failed");
    } finally {
      setBusy(false);
    }
  };

  const input =
    "w-full rounded-xl border border-input bg-surface-2/70 py-3 pl-11 pr-3.5 text-sm outline-none focus:border-gold";

  return (
    <div className="relative grid min-h-screen place-items-center px-4">
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute left-1/4 top-0 size-[36rem] rounded-full bg-gold/10 blur-[130px] animate-aura" />
      </div>

      <div className="w-full max-w-sm rounded-3xl glass p-7 shadow-lux">
        <img src={settings.logoMain} alt="" className="mx-auto h-14 w-auto" />
        <h1 className="mt-5 text-center font-display text-2xl">Admin Panel</h1>
        <p className="mt-1 text-center text-xs text-muted-foreground">
          {settings.fullName}
        </p>

        {!configured && (
          <p className="mt-5 flex gap-2 rounded-xl border border-gold/40 bg-surface-2/60 p-3 text-[11px] leading-snug text-muted-foreground">
            <ShieldAlert size={15} className="mt-0.5 shrink-0 text-gold" />
            Firebase keys are not added yet. Fill{" "}
            <code className="text-gold">src/lib/firebase-config.ts</code> and create an admin user
            in Firebase Auth to log in.
          </p>
        )}

        <form onSubmit={submit} className="mt-6 space-y-3">
          <div className="relative">
            <Mail size={16} className="absolute left-4 top-3.5 text-gold" />
            <input
              className={input}
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="username"
            />
          </div>
          <div className="relative">
            <Lock size={16} className="absolute left-4 top-3.5 text-gold" />
            <input
              className={input}
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </div>
          <button
            disabled={busy || !configured}
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient py-3.5 text-sm font-bold text-primary-foreground disabled:opacity-45"
          >
            {busy && <Loader2 size={15} className="animate-spin" />} Sign in
          </button>
        </form>

        <button
          onClick={async () => {
            if (!email) return toast.error("Enter your email first.");
            try {
              await adminReset(email.trim());
              toast.success("Password reset email sent.");
            } catch {
              toast.error("Could not send reset email.");
            }
          }}
          className="mt-4 w-full text-center text-xs text-muted-foreground hover:text-gold"
        >
          Forgot password?
        </button>

        <Link
          to="/"
          className="mt-6 flex items-center justify-center gap-1.5 text-xs text-muted-foreground hover:text-gold"
        >
          <ArrowLeft size={13} /> Back to website
        </Link>
      </div>
    </div>
  );
}
