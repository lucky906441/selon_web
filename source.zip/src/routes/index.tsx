import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Star,
  MapPin,
  Phone,
  CalendarCheck,
  ArrowRight,
  Check,
  Clock,
  ChevronDown,
  Sparkles,
  Instagram,
} from "lucide-react";
import { SiteLayout } from "@/components/site-layout";
import { Reveal, Tilt, CountUp, SectionTitle } from "@/components/motion";
import { SocialIcons } from "@/components/social-icons";
import { Lightbox } from "@/components/lightbox";
import { useStore } from "@/lib/store";
import { WHY_US } from "@/lib/seed-data";
import { inr, durationLabel } from "@/lib/booking-utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mehak's Makeover Unisex Salon — Premium Beauty Studio in Brahmapur" },
      {
        name: "description",
        content:
          "Brahmapur's premium unisex salon for bridal makeup, hair spa, keratin, hydra facial and grooming. Book your slot online in under a minute.",
      },
      { property: "og:title", content: "Mehak's Makeover Unisex Salon — Brahmapur" },
      {
        property: "og:description",
        content:
          "Where beauty meets artistry. Bridal makeup, hair, skin, nails and men's grooming with online booking.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <SiteLayout>
      <Hero />
      <TrustBar />
      <AboutSnippet />
      <ServicesGrid />
      <Packages />
      <GalleryPreview />
      <WhyUs />
      <Testimonials />
      <BookingBand />
      <LocationMap />
      <InstagramStrip />
      <Faq />
      <JsonLd />
    </SiteLayout>
  );
}

/* ------------------------------ HERO ------------------------------ */
function Hero() {
  const { settings, gallery } = useStore();
  const ref = React.useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = React.useState({ x: 0, y: 0 });
  const [scroll, setScroll] = React.useState(0);

  React.useEffect(() => {
    const onScroll = () => setScroll(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const onMove = (e: React.MouseEvent) => {
    if (window.matchMedia("(pointer: coarse)").matches) return;
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    setTilt({ x: (e.clientX - r.left) / r.width - 0.5, y: (e.clientY - r.top) / r.height - 0.5 });
  };

  const shots = gallery.slice(0, 3);

  return (
    <section
      ref={ref}
      onMouseMove={onMove}
      className="relative overflow-hidden px-4 pb-20 pt-14 sm:px-6 sm:pt-20 lg:pt-24"
    >
      <div className="mx-auto grid max-w-[1320px] items-center gap-12 lg:grid-cols-[1.05fr_1fr]">
        <div className="text-center lg:text-left" style={{ transform: `translateY(${scroll * -0.05}px)` }}>
          <Reveal>
            <span className="inline-flex items-center gap-2 rounded-full border border-gold/30 bg-card/70 px-4 py-2 text-[10px] uppercase tracking-[0.3em] text-gold shadow-lux backdrop-blur">
              <Sparkles size={12} className="animate-float-y" /> Brahmapur · Unisex Salon
            </span>
          </Reveal>
          <Reveal delay={80}>
            <h1 className="mt-6 font-display text-[clamp(2.9rem,12vw,5rem)] font-medium leading-[0.94] tracking-tight">
              Where Beauty
              <br />
              <span className="relative inline-block">
                <span className="italic text-gradient-gold">Meets Artistry</span>
                <span
                  aria-hidden
                  className="absolute -bottom-2 left-0 h-[3px] w-full rounded-full bg-gold-gradient opacity-70"
                />
              </span>
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="mx-auto mt-8 max-w-md text-[15px] leading-relaxed text-muted-foreground lg:mx-0 lg:max-w-lg">
              A premium studio for bridal artistry, hair transformations, advanced skin care and
              men's grooming.
              <span className="mt-2 block font-medium text-foreground">
                Book your seat, skip the wait.
              </span>
            </p>
          </Reveal>
          <Reveal delay={240} className="mt-9 flex flex-col gap-3 sm:flex-row sm:flex-wrap lg:justify-start">
            <Link
              to="/booking"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-7 py-4 text-sm font-bold tracking-wide text-primary-foreground shadow-lux transition-transform hover:scale-[1.03]"
            >
              <CalendarCheck size={18} />
              Book Appointment
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </Link>
            <a
              href={`tel:${settings.phone}`}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-gold/30 bg-card/60 px-7 py-4 text-sm font-semibold text-gold backdrop-blur transition-colors hover:bg-surface-2"
            >
              <Phone size={17} /> Call Now
            </a>
          </Reveal>
          <Reveal
            delay={320}
            className="mt-9 flex flex-col items-center gap-4 rounded-3xl border border-border bg-card/50 p-4 backdrop-blur sm:flex-row sm:justify-center sm:gap-6 lg:justify-start lg:rounded-none lg:border-0 lg:bg-transparent lg:p-0 lg:backdrop-blur-none"
          >
            <div className="flex items-center gap-2">
              <div className="flex text-gold">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} size={15} fill="currentColor" />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">4.9 · 500+ reviews</span>
            </div>
            <span aria-hidden className="hidden h-8 w-px bg-border sm:block" />
            <a
              href={settings.mapDirectionsUrl}
              target="_blank"
              rel="noreferrer"
              className="flex max-w-xs items-start gap-2 text-center text-xs leading-relaxed text-muted-foreground hover:text-gold sm:text-left"
            >
              <MapPin size={14} className="mt-0.5 shrink-0 text-gold" />
              {settings.address}
            </a>
          </Reveal>
        </div>


        {/* 3D photo stack */}
        <div
          className="relative mx-auto aspect-4/5 w-[82%] max-w-md sm:w-full"
          style={{ perspective: "1600px" }}
        >
          <div
            className="relative size-full transition-transform duration-300 ease-out"
            style={{
              transform: `rotateY(${tilt.x * 12}deg) rotateX(${-tilt.y * 12}deg)`,
              transformStyle: "preserve-3d",
            }}
          >
            {shots.map((g, i) => (
              <img
                key={g.id}
                src={g.url}
                alt={g.caption}
                loading={i === 0 ? "eager" : "lazy"}
                fetchPriority={i === 0 ? "high" : "auto"}
                className={cn(
                  "absolute rounded-3xl object-cover object-top shadow-lux",
                  i === 0 && "inset-0 size-full",
                  i === 1 && "-left-6 bottom-6 h-40 w-32 sm:h-52 sm:w-40",
                  i === 2 && "-right-5 top-8 h-32 w-28 sm:h-40 sm:w-32",
                )}
                style={{ transform: `translateZ(${[0, 40, 28][i]}px)` }}
              />
            ))}
            <div
              className="absolute -bottom-5 right-2 rounded-2xl glass px-4 py-3 shadow-lux"
              style={{ transform: "translateZ(55px)" }}
            >
              <p className="font-display text-2xl text-gradient-gold">9+</p>
              <p className="text-[10px] uppercase tracking-widest text-muted-foreground">
                Years of glam
              </p>
            </div>
            <img
              src={settings.logoSecondary}
              alt=""
              aria-hidden
              className="absolute -left-4 top-0 size-16 animate-float-y rounded-2xl glass p-2"
              style={{ transform: "translateZ(60px)" }}
            />
          </div>
        </div>
      </div>

      <div className="mt-16 flex justify-center">
        <ChevronDown size={22} className="animate-float-y text-gold/70" />
      </div>
    </section>
  );
}

/* ---------------------------- TRUST BAR ---------------------------- */
function TrustBar() {
  const { settings } = useStore();
  const stats = [
    { n: settings.stats.clients, s: "+", label: "Happy Clients" },
    { n: settings.stats.years, s: "+", label: "Years Experience" },
    { n: settings.stats.services, s: "+", label: "Services" },
    { n: settings.stats.stylists, s: "", label: "Expert Artists" },
  ];
  return (
    <section className="px-4 sm:px-6">
      <Reveal className="mx-auto grid max-w-[1320px] grid-cols-2 gap-4 rounded-3xl glass p-6 shadow-lux sm:p-8 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="text-center">
            <p className="font-display text-3xl text-gradient-gold sm:text-4xl">
              <CountUp to={s.n} suffix={s.s} />
            </p>
            <p className="mt-1 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
              {s.label}
            </p>
          </div>
        ))}
      </Reveal>
    </section>
  );
}

/* ---------------------------- ABOUT ---------------------------- */
function AboutSnippet() {
  const { gallery, settings } = useStore();
  return (
    <section className="px-4 py-24 sm:px-6">
      <div className="mx-auto grid max-w-[1320px] items-center gap-12 lg:grid-cols-2">
        <Reveal className="relative">
          <img
            src={gallery[3]?.url}
            alt="Inside Mehak's Makeover salon"
            loading="lazy"
            className="aspect-4/3 w-full rounded-3xl object-cover object-top shadow-lux"
          />
          <img
            src={gallery[6]?.url}
            alt="Styling in progress"
            loading="lazy"
            className="absolute -bottom-8 -right-4 hidden h-44 w-36 rounded-2xl object-cover object-top shadow-lux sm:block"
          />
        </Reveal>
        <div>
          <SectionTitle
            center={false}
            eyebrow="Our Story"
            title={<>A studio built on trust, skill and glow</>}
            subtitle={`${settings.fullName} has been Brahmapur's go-to beauty destination for nearly a decade. From everyday grooming to once-in-a-lifetime bridal looks, our certified artists blend international technique with a warm, personal touch.`}
          />
          <Reveal delay={120} className="mt-7 space-y-3">
            {[
              "Certified bridal & HD makeup artists",
              "International product lines only",
              "Strict hygiene & single-use kits",
              "Slot-based booking — no waiting",
            ].map((t) => (
              <p key={t} className="flex items-center gap-3 text-sm text-muted-foreground">
                <span className="grid size-5 place-items-center rounded-full bg-gold-gradient">
                  <Check size={12} className="text-primary-foreground" />
                </span>
                {t}
              </p>
            ))}
          </Reveal>
          <Reveal delay={200}>
            <Link
              to="/about"
              className="mt-8 inline-flex items-center gap-2 text-sm font-semibold text-gold hover:gap-3"
            >
              More about us <ArrowRight size={16} />
            </Link>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ---------------------------- SERVICES ---------------------------- */
function ServicesGrid() {
  const { categories, services } = useStore();
  return (
    <section id="services" className="px-4 py-16 sm:px-6">
      <SectionTitle
        eyebrow="What we do"
        title="Signature services"
        subtitle="Eight categories, sixty plus treatments — all bookable online with live pricing."
      />
      <div className="mx-auto mt-12 grid max-w-[1320px] gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {categories
          .filter((c) => c.visible)
          .map((c, i) => {
            const list = services.filter((s) => s.visible && s.categoryId === c.id);
            const from = list.length ? Math.min(...list.map((s) => s.offerPrice ?? s.price)) : 0;
            return (
              <Reveal key={c.id} delay={i * 60}>
                <Tilt className="h-full">
                  <div className="flex h-full flex-col rounded-3xl border border-border bg-surface/70 p-6 transition-colors hover:border-gold/60 hover:glow-gold">
                    <span className="grid size-11 place-items-center rounded-2xl bg-gold-gradient text-primary-foreground">
                      <Sparkles size={18} />
                    </span>
                    <h3 className="mt-4 font-display text-xl">{c.name}</h3>
                    <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">
                      {list
                        .slice(0, 3)
                        .map((s) => s.name)
                        .join(" · ")}
                    </p>
                    <p className="mt-4 text-sm text-gold">from {inr(from)}</p>
                    <Link
                      to="/booking"
                      className="mt-5 inline-flex items-center gap-1.5 self-start rounded-full border border-gold/50 px-4 py-2 text-xs font-semibold text-gold transition-colors hover:bg-gold-gradient hover:text-primary-foreground"
                    >
                      Book <ArrowRight size={13} />
                    </Link>
                  </div>
                </Tilt>
              </Reveal>
            );
          })}
      </div>
      <Reveal className="mt-10 text-center">
        <Link
          to="/services"
          className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm text-gold hover:bg-surface-2"
        >
          View full price list <ArrowRight size={15} />
        </Link>
      </Reveal>
    </section>
  );
}

/* ---------------------------- PACKAGES ---------------------------- */
function Packages() {
  const { packages } = useStore();
  return (
    <section className="px-4 py-20 sm:px-6">
      <SectionTitle
        eyebrow="Best value"
        title="Curated packages"
        subtitle="Everything you need for the big day, bundled at a better price."
      />
      <div className="mx-auto mt-12 grid max-w-[1320px] gap-5 lg:grid-cols-3">
        {packages
          .filter((p) => p.visible)
          .map((p, i) => (
            <Reveal key={p.id} delay={i * 90}>
              <Tilt intensity={7} className="h-full">
                <article
                  className={cn(
                    "relative flex h-full flex-col overflow-hidden rounded-3xl border bg-surface/70",
                    p.badge ? "border-gold glow-gold" : "border-border",
                  )}
                >
                  {p.badge && (
                    <span className="absolute right-4 top-4 z-10 rounded-full bg-gold-gradient px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-primary-foreground">
                      {p.badge}
                    </span>
                  )}
                  <img
                    src={p.image}
                    alt={p.name}
                    loading="lazy"
                    className="h-52 w-full object-cover object-top"
                  />
                  <div className="flex flex-1 flex-col p-6">
                    <h3 className="font-display text-2xl">{p.name}</h3>
                    <p className="mt-1 font-display text-3xl text-gradient-gold">{inr(p.price)}</p>
                    <ul className="mt-5 flex-1 space-y-2.5 text-sm text-muted-foreground">
                      {p.includes.map((t) => (
                        <li key={t} className="flex gap-2.5">
                          <Check size={15} className="mt-0.5 shrink-0 text-gold" />
                          {t}
                        </li>
                      ))}
                    </ul>
                    <Link
                      to="/booking"
                      className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-5 py-3 text-sm font-bold text-primary-foreground"
                    >
                      Reserve this package
                    </Link>
                  </div>
                </article>
              </Tilt>
            </Reveal>
          ))}
      </div>
    </section>
  );
}

/* ---------------------------- GALLERY ---------------------------- */
function GalleryPreview() {
  const { gallery } = useStore();
  const [open, setOpen] = React.useState<number | null>(null);
  const items = gallery.filter((g) => g.visible).slice(0, 10);

  return (
    <section className="py-20">
      <SectionTitle
        eyebrow="Our work"
        title="The transformation gallery"
        subtitle="Real clients, real results — straight from our studio floor."
      />
      <Reveal className="no-scrollbar mt-12 flex gap-4 overflow-x-auto px-4 pb-6 sm:px-6">
        {items.map((g, i) => (
          <button
            key={g.id}
            onClick={() => setOpen(i)}
            className="group relative h-72 w-52 shrink-0 overflow-hidden rounded-3xl border border-border shadow-lux transition-transform duration-500 hover:-translate-y-2 sm:h-96 sm:w-72"
          >
            <img
              src={g.url}
              alt={g.caption}
              loading="lazy"
              className="size-full object-cover object-top transition-transform duration-700 group-hover:scale-110"
            />
            <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-background to-transparent p-4 pt-12 text-left text-xs text-foreground/90">
              {g.category}
            </span>
          </button>
        ))}
      </Reveal>
      <div className="text-center">
        <Link
          to="/gallery"
          className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm text-gold hover:bg-surface-2"
        >
          View all photos <ArrowRight size={15} />
        </Link>
      </div>
      <Lightbox items={items} index={open} onClose={() => setOpen(null)} />
    </section>
  );
}

/* ---------------------------- WHY US ---------------------------- */
function WhyUs() {
  return (
    <section className="px-4 py-20 sm:px-6">
      <SectionTitle eyebrow="Why Mehak's" title="Six reasons clients keep coming back" />
      <div className="mx-auto mt-12 grid max-w-[1320px] gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {WHY_US.map((w, i) => (
          <Reveal key={w.title} delay={i * 60}>
            <div className="h-full rounded-3xl border border-border bg-surface/60 p-6 transition-colors hover:border-gold/50">
              <span className="font-display text-3xl text-gold/40">0{i + 1}</span>
              <h3 className="mt-2 font-display text-xl">{w.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{w.desc}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------- TESTIMONIALS ---------------------------- */
function Testimonials() {
  const { testimonials } = useStore();
  const list = testimonials.filter((t) => t.visible);
  return (
    <section className="overflow-hidden py-20">
      <SectionTitle eyebrow="Loved by Brahmapur" title="Client stories" />
      <div className="no-scrollbar mt-12 flex gap-4 overflow-x-auto px-4 pb-4 sm:px-6">
        {list.map((t, i) => (
          <Reveal key={t.id} delay={i * 60}>
            <figure className="flex h-full w-[19rem] shrink-0 flex-col rounded-3xl glass p-6 shadow-lux sm:w-[22rem]">
              <div className="flex text-gold">
                {Array.from({ length: t.rating }).map((_, k) => (
                  <Star key={k} size={14} fill="currentColor" />
                ))}
              </div>
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground">
                "{t.text}"
              </blockquote>
              <figcaption className="mt-5 flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-full bg-gold-gradient font-display text-primary-foreground">
                  {t.name.charAt(0)}
                </span>
                <span>
                  <span className="block text-sm font-medium">{t.name}</span>
                  <span className="block text-xs text-muted-foreground">
                    {new Date(t.date).toLocaleDateString("en-IN", {
                      month: "short",
                      year: "numeric",
                    })}
                  </span>
                </span>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------- BOOKING BAND ---------------------------- */
function BookingBand() {
  const { services } = useStore();
  const popular = services.filter((s) => s.popular).slice(0, 6);
  return (
    <section className="px-4 py-20 sm:px-6">
      <Reveal className="mx-auto max-w-[1320px] overflow-hidden rounded-[2rem] border border-gold/40 bg-surface/70 p-8 shadow-lux sm:p-12">
        <div className="grid items-center gap-8 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <h2 className="font-display text-3xl sm:text-4xl">
              Your glow-up is <span className="text-gradient-gold">one tap</span> away
            </h2>
            <p className="mt-3 max-w-lg text-sm text-muted-foreground">
              Pick your services, choose your artist, lock your slot. Instant confirmation on
              WhatsApp — no queues, no guesswork.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link
                to="/booking"
                className="inline-flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-4 text-sm font-bold text-primary-foreground animate-pulse-ring"
              >
                <CalendarCheck size={18} /> Book Appointment
              </Link>
              <SocialIcons />
            </div>
          </div>
          <ul className="space-y-2.5">
            {popular.map((s) => (
              <li
                key={s.id}
                className="flex items-center justify-between gap-4 rounded-2xl border border-border bg-surface-2/60 px-4 py-3 text-sm"
              >
                <span className="min-w-0 truncate">{s.name}</span>
                <span className="flex shrink-0 items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock size={12} /> {durationLabel(s.durationMin)}
                  </span>
                  <span className="font-semibold text-gold">{inr(s.offerPrice ?? s.price)}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      </Reveal>
    </section>
  );
}

/* ---------------------------- MAP ---------------------------- */
function LocationMap() {
  const { settings } = useStore();
  return (
    <section className="px-4 py-20 sm:px-6">
      <SectionTitle eyebrow="Find us" title="Visit the studio" />
      <div className="mx-auto mt-12 grid max-w-[1320px] gap-5 lg:grid-cols-[1fr_1.4fr]">
        <Reveal className="rounded-3xl glass p-7 shadow-lux">
          <h3 className="font-display text-2xl">{settings.name}</h3>
          <p className="mt-1 text-xs uppercase tracking-[0.24em] text-gold">Unisex Salon</p>
          <p className="mt-5 flex gap-3 text-sm text-muted-foreground">
            <MapPin size={17} className="mt-0.5 shrink-0 text-gold" />
            {settings.address}
          </p>
          <p className="mt-3 flex gap-3 text-sm text-muted-foreground">
            <Phone size={17} className="shrink-0 text-gold" />
            <a href={`tel:${settings.phone}`} className="hover:text-gold">
              {settings.phone}
            </a>
          </p>
          <a
            href={settings.mapDirectionsUrl}
            target="_blank"
            rel="noreferrer"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-gold-gradient px-6 py-3 text-sm font-bold text-primary-foreground"
          >
            <MapPin size={16} /> Get Directions
          </a>
          <SocialIcons className="mt-6" />
        </Reveal>
        <Reveal delay={100} className="overflow-hidden rounded-3xl border border-border shadow-lux">
          <iframe
            title="Mehak's Makeover location map"
            src={settings.mapEmbedUrl}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="h-[22rem] w-full lg:h-full"
          />
        </Reveal>
      </div>
    </section>
  );
}

/* ---------------------------- INSTAGRAM ---------------------------- */
function InstagramStrip() {
  const { gallery, socials } = useStore();
  const ig = socials.find((s) => s.id === "instagram" && s.visible);
  if (!ig) return null;
  return (
    <section className="py-16">
      <SectionTitle
        eyebrow="@mehaks_makeover"
        title="Follow the glow"
        subtitle="Daily looks, behind-the-scenes and offers on Instagram."
      />
      <div className="mt-10 grid grid-cols-3 gap-2 px-4 sm:grid-cols-6 sm:px-6">
        {gallery.slice(8, 14).map((g) => (
          <a
            key={g.id}
            href={ig.url}
            target="_blank"
            rel="noreferrer"
            className="group relative aspect-square overflow-hidden rounded-2xl border border-border"
          >
            <img
              src={g.url}
              alt={g.caption}
              loading="lazy"
              className="size-full object-cover object-top transition-transform duration-500 group-hover:scale-110"
            />
            <span className="absolute inset-0 grid place-items-center bg-background/70 opacity-0 transition-opacity group-hover:opacity-100">
              <Instagram size={20} className="text-gold" />
            </span>
          </a>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------- FAQ ---------------------------- */
function Faq() {
  const { faqs } = useStore();
  const [open, setOpen] = React.useState<string | null>(null);
  return (
    <section className="px-4 py-20 sm:px-6">
      <SectionTitle eyebrow="Good to know" title="Frequently asked questions" />
      <div className="mx-auto mt-10 max-w-3xl space-y-3">
        {faqs
          .filter((f) => f.visible)
          .map((f, i) => (
            <Reveal key={f.id} delay={i * 50}>
              <div className="overflow-hidden rounded-2xl border border-border bg-surface/60">
                <button
                  onClick={() => setOpen(open === f.id ? null : f.id)}
                  aria-expanded={open === f.id}
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left text-sm font-medium"
                >
                  {f.question}
                  <ChevronDown
                    size={17}
                    className={cn(
                      "shrink-0 text-gold transition-transform",
                      open === f.id && "rotate-180",
                    )}
                  />
                </button>
                <div
                  className={cn(
                    "grid transition-all duration-400",
                    open === f.id ? "grid-rows-[1fr]" : "grid-rows-[0fr]",
                  )}
                >
                  <p className="overflow-hidden px-5 text-sm leading-relaxed text-muted-foreground">
                    <span className="block pb-5">{f.answer}</span>
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
      </div>
    </section>
  );
}

/* ---------------------------- SEO JSON-LD ---------------------------- */
function JsonLd() {
  const { settings, socials, gallery } = useStore();
  const data = {
    "@context": "https://schema.org",
    "@type": "HairSalon",
    name: settings.fullName,
    image: gallery[0]?.url,
    logo: settings.logoMain,
    telephone: settings.phone,
    priceRange: "₹₹",
    address: {
      "@type": "PostalAddress",
      streetAddress: "4th floor, Janata City Centre, Telephone Bhawan Rd, near KFC",
      addressLocality: "Brahmapur",
      addressRegion: "Odisha",
      postalCode: "760001",
      addressCountry: "IN",
    },
    openingHours: Object.entries(settings.openingHours)
      .filter(([, h]) => !h.closed)
      .map(([d, h]) => `${d.slice(0, 2)} ${h.open}-${h.close}`),
    sameAs: socials.filter((s) => s.visible).map((s) => s.url),
  };
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}
