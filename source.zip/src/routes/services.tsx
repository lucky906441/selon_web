import * as React from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, ArrowRight } from "lucide-react";
import { SiteLayout } from "@/components/site-layout";
import { Reveal, SectionTitle } from "@/components/motion";
import { useStore } from "@/lib/store";
import { inr, durationLabel } from "@/lib/booking-utils";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services & Price List — Mehak's Makeover Unisex Salon" },
      {
        name: "description",
        content:
          "Full service menu and transparent pricing: haircuts, keratin, hair spa, facials, HD bridal makeup, nails, spa and men's grooming in Brahmapur.",
      },
      { property: "og:title", content: "Services & Prices — Mehak's Makeover" },
      {
        property: "og:description",
        content: "60+ salon services with live pricing and online booking in Brahmapur, Odisha.",
      },
    ],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  const { categories, services } = useStore();
  const [active, setActive] = React.useState("all");
  const cats = categories.filter((c) => c.visible);
  const list = services.filter(
    (s) => s.visible && (active === "all" || s.categoryId === active),
  );

  return (
    <SiteLayout>
      <section className="px-4 py-16 sm:px-6">
        <SectionTitle
          eyebrow="Menu & pricing"
          title="Every service, one honest price list"
          subtitle="Prices are indicative and may vary with hair length, product choice and add-ons. Ask us anything before you book."
        />

        <div className="no-scrollbar mx-auto mt-10 flex max-w-[1320px] gap-2 overflow-x-auto pb-2">
          {[{ id: "all", name: "All" }, ...cats].map((c) => (
            <button
              key={c.id}
              onClick={() => setActive(c.id)}
              className={cn(
                "whitespace-nowrap rounded-full border px-5 py-2.5 text-sm transition-all",
                active === c.id
                  ? "border-gold bg-gold-gradient font-semibold text-primary-foreground"
                  : "border-border text-muted-foreground hover:text-gold",
              )}
            >
              {c.name}
            </button>
          ))}
        </div>

        <div className="mx-auto mt-8 grid max-w-[1320px] gap-3 md:grid-cols-2">
          {list.map((s, i) => (
            <Reveal key={s.id} delay={Math.min(i, 8) * 40}>
              <article className="flex h-full items-start justify-between gap-4 rounded-2xl border border-border bg-surface/60 p-5 transition-colors hover:border-gold/50">
                <div className="min-w-0">
                  <h3 className="flex items-center gap-2 font-medium">
                    {s.name}
                    {s.popular && (
                      <span className="rounded-full bg-gold-gradient px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-primary-foreground">
                        Popular
                      </span>
                    )}
                  </h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                    {s.description}
                  </p>
                  <p className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock size={12} className="text-gold" /> {durationLabel(s.durationMin)}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="font-display text-xl text-gradient-gold">
                    {inr(s.offerPrice ?? s.price)}
                  </p>
                  <Link
                    to="/booking"
                    className="mt-2 inline-flex items-center gap-1 rounded-full border border-gold/50 px-3 py-1.5 text-[11px] font-semibold text-gold hover:bg-gold-gradient hover:text-primary-foreground"
                  >
                    Book <ArrowRight size={11} />
                  </Link>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
